"use client";
// On-chain side of ArkhamPad: networks, contract calls, signed (gasless) requests.
import { createPublicClient, createWalletClient, defineChain, domainSeparator, encodeFunctionData, http, keccak256, parseAbi, parseEventLogs, type Address, type Hex, type PublicClient } from "viem";
import { baseSepolia } from "viem/chains";

export const RELAYER = process.env.NEXT_PUBLIC_RELAYER_URL || "https://arkhampad-web-production.up.railway.app";

export const robinhoodTestnet = defineChain({
  id: 46630,
  name: "Robinhood Chain Testnet",
  nativeCurrency: { name: "Ether", symbol: "ETH", decimals: 18 },
  rpcUrls: { default: { http: ["https://rpc.testnet.chain.robinhood.com"] } },
  testnet: true,
});

export type Net = { id: number; name: string; short: string; rpc: string; hub: Address; router: Address; usdc: Address; faucet: boolean; faucetUrl?: string; usdDecimals?: number; approvals?: "permit" | "gas" };

// Contract addresses come from contracts/deployments/<chainId>.json.
const DEFAULT_NETS: Net[] = [
  { id: 84532, name: "Base Sepolia", short: "Base", rpc: "https://sepolia.base.org", hub: "0x9987E66B818ED246cB1687D651e975E952101E4a", router: "0xcB2dC6690bb3556a718Cbe2281017DC66F5A1A7E", usdc: "0x036CbD53842c5426634e7929541eC2318f3dCF7e", faucet: false, faucetUrl: "https://faucet.circle.com" },
  { id: 46630, name: "Robinhood Testnet", short: "Robinhood", rpc: "https://rpc.testnet.chain.robinhood.com", hub: "0xA8c03CFB5aE340fdCE22F94CE83100daef33DEF0", router: "0xEFbd358D0120AEbAA77De2805294FAE31d9D7D2D", usdc: "0x47AfD49069EAbEcfb153926f1f652249fFb61b57", faucet: true },
];
// Local test builds can point everything at a local chain.
export const NETS: Net[] = process.env.NEXT_PUBLIC_NETS ? JSON.parse(process.env.NEXT_PUBLIC_NETS) : DEFAULT_NETS;
export const netOf = (id: number) => NETS.find((n) => n.id === id) ?? null;
export const viemChain = (id: number) => (id === 84532 ? baseSepolia : id === 46630 ? robinhoodTestnet : defineChain({ id, name: `chain ${id}`, nativeCurrency: { name: "Ether", symbol: "ETH", decimals: 18 }, rpcUrls: { default: { http: [netOf(id)?.rpc ?? ""] } } }));

const clients = new Map<number, PublicClient>();
export function client(id: number): PublicClient {
  let c = clients.get(id);
  if (!c) {
    const n = netOf(id);
    if (!n) throw new Error("Unknown network");
    c = createPublicClient({ chain: viemChain(id), transport: http(n.rpc, { retryCount: 2, timeout: 15_000 }), pollingInterval: 250 }) as PublicClient;
    clients.set(id, c);
  }
  return c;
}

export const ERC20 = parseAbi([
  "function balanceOf(address) view returns (uint256)",
  "function allowance(address,address) view returns (uint256)",
  "function nonces(address) view returns (uint256)",
  "function name() view returns (string)",
  "function version() view returns (string)",
  "function symbol() view returns (string)",
]);
export const CURVE = parseAbi([
  "function quoteBuy(uint256) view returns (uint256)",
  "function quoteSell(uint256) view returns (uint256)",
  "function phase() view returns (uint8)",
  "function coin() view returns (address)",
  "function creator() view returns (address)",
  "function marketCap() view returns (uint256)",
  "function usdcReserve() view returns (uint256)",
  "function vUsdc() view returns (uint256)",
  "function vCoin() view returns (uint256)",
  "function creatorFees() view returns (uint256)",
  "function feeMode() view returns (uint8)",
  "event Trade(address indexed trader, bool indexed isBuy, uint256 usdcAmount, uint256 coinAmount, uint256 fee, uint256 vUsdcAfter, uint256 vCoinAfter)",
]);
export const HUB = parseAbi([
  "function curveOf(address) view returns (address)",
  "event CoinCreated(address indexed coin, address indexed curve, address indexed creator, string name, string symbol, string metadataURI, uint256 lockSeconds, uint8 feeMode)",
]);
export const PROMOTE = parseAbi(["function plans(uint8) view returns (uint64 seconds_, uint128 price, bool active)", "function promoter() view returns (address)"]);
const ROUTER_VIEW = parseAbi(["function promoter() view returns (address)", "function quotePool(address coin, bool isBuy, uint256 amountIn) returns (uint256)"]);
const POOL_EVENT = parseAbi(["event PoolTraded(address indexed user, address indexed coin, bool isBuy, uint256 usdcAmount, uint256 coinAmount, uint256 fee, uint256 nonce)"]);

export const FEE = 10_000n; // smallest network fee ($0.01, site units: 6 decimals); the live one comes from the relayer

// Live network fee per kind of request: what the relayer really spends on gas, in USDC.
// Cached for 20 seconds and fetched ahead of time, so a trade never waits on it.
type FeeKind = "buy" | "sell" | "poolBuy" | "poolSell" | "launch" | "withdraw" | "promote" | "extSwap";
const feeCache = new Map<string, { at: number; fee: bigint }>();
const feeLoads = new Map<string, Promise<bigint>>();
export async function netFee(chainId: number, kind: FeeKind): Promise<bigint> {
  const key = `${chainId}:${kind}`;
  const hit = feeCache.get(key);
  if (hit && Date.now() - hit.at < 20_000) return hit.fee;
  let p = feeLoads.get(key);
  if (!p) {
    p = (async () => {
      try {
        const r = await fetch(`${RELAYER}/fee?chainId=${chainId}&kind=${kind}`, { signal: AbortSignal.timeout(3000) });
        const j = await r.json();
        if (j?.busy) throw new TradeError("The network is very busy right now. Please try again in a few minutes.");
        const fee = BigInt(String(j?.fee ?? "0"));
        if (r.ok && fee >= FEE) { feeCache.set(key, { at: Date.now(), fee }); return fee; }
      } catch (e) { if (e instanceof TradeError) throw e; }
      return hit?.fee ?? FEE;
    })().finally(() => feeLoads.delete(key));
    feeLoads.set(key, p);
  }
  return p;
}
/** Last known fee without waiting (for estimates on screen). */
export function lastFee(chainId: number, kind: FeeKind): bigint { return feeCache.get(`${chainId}:${kind}`)?.fee ?? FEE; }
/** Fetches the usual fees ahead of a trade. */
export function warmFees(chainId: number, kinds: FeeKind[] = ["buy", "sell"]) { for (const k of kinds) netFee(chainId, k).catch(() => {}); }

// The site counts dollars with 6 decimals everywhere. Some networks' dollar token has more
// (BNB's USDC: 18). These convert at the edge, right where amounts go to or come from a chain.
const decOf = (n: Net) => n.usdDecimals ?? 6;
const scaleOf = (n: Net) => 10n ** BigInt(decOf(n) - 6);
const up = (n: Net, v: bigint) => v * scaleOf(n); // site units -> chain units
const down = (n: Net, v: bigint) => v / scaleOf(n); // chain units -> site units
export const MAX = 2n ** 256n - 1n;
export const toUsdc = (n: number) => BigInt(Math.round(n * 1e6));
export const fromUsdc = (v: bigint) => Number(v) / 1e6;
export const fromCoin = (v: bigint) => Number(v) / 1e18;

export type Signer = {
  address: Address;
  signTypedData: (chainId: number, typed: TypedData) => Promise<Hex>;
  /** Sends a transaction from the user's wallet (only needed for one-time approvals on networks without permit). */
  sendTx?: (chainId: number, tx: { to: Address; data: Hex }) => Promise<Hex>;
};
export type TypedData = { domain: Record<string, unknown>; types: Record<string, { name: string; type: string }[]>; primaryType: string; message: Record<string, unknown> };

const F = (pairs: [string, string][]) => pairs.map(([name, type]) => ({ name, type }));
const TYPES = {
  Buy: F([["user", "address"], ["curve", "address"], ["usdcIn", "uint256"], ["minCoinsOut", "uint256"], ["fee", "uint256"], ["nonce", "uint256"], ["deadline", "uint256"]]),
  Sell: F([["user", "address"], ["curve", "address"], ["coinAmount", "uint256"], ["minUsdcOut", "uint256"], ["fee", "uint256"], ["nonce", "uint256"], ["deadline", "uint256"]]),
  Create: F([["user", "address"], ["name", "string"], ["symbol", "string"], ["metadataURI", "string"], ["lockSeconds", "uint256"], ["feeMode", "uint8"], ["launchUsdc", "uint256"], ["minCoinsOut", "uint256"], ["fee", "uint256"], ["nonce", "uint256"], ["deadline", "uint256"]]),
  Withdraw: F([["user", "address"], ["to", "address"], ["amount", "uint256"], ["fee", "uint256"], ["nonce", "uint256"], ["deadline", "uint256"]]),
  PoolBuy: F([["user", "address"], ["coin", "address"], ["usdcIn", "uint256"], ["minCoinsOut", "uint256"], ["fee", "uint256"], ["nonce", "uint256"], ["deadline", "uint256"]]),
  PoolSell: F([["user", "address"], ["coin", "address"], ["coinAmount", "uint256"], ["minUsdcOut", "uint256"], ["fee", "uint256"], ["nonce", "uint256"], ["deadline", "uint256"]]),
  Promote: F([["user", "address"], ["coin", "address"], ["coinChainId", "uint256"], ["plan", "uint8"], ["maxPrice", "uint256"], ["fee", "uint256"], ["nonce", "uint256"], ["deadline", "uint256"]]),
  Permit: F([["owner", "address"], ["spender", "address"], ["value", "uint256"], ["nonce", "uint256"], ["deadline", "uint256"]]),
};

const routerDomain = (n: Net) => ({ name: "ArkhamPad", version: "1", chainId: n.id, verifyingContract: n.router });
const deadline = () => BigInt(Math.floor(Date.now() / 1000) + 600);
function randomNonce(): bigint {
  const a = new Uint32Array(2);
  crypto.getRandomValues(a);
  return (BigInt(a[0]) << 32n) | BigInt(a[1]);
}
const S = (v: bigint | number) => v.toString();

// ---------------------------------------------------------------- relayer
export class TradeError extends Error {}

type Relayed = { hash: Hex; status?: string; logs?: { address: Address; data: Hex; topics: Hex[] }[] };

async function relay(body: Record<string, unknown>): Promise<Relayed> {
  let r: Response;
  try {
    r = await fetch(`${RELAYER}/relay`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
  } catch {
    throw new TradeError("Can't reach ArkhamPad right now. Check your connection.");
  }
  const j = await r.json().catch(() => ({}));
  if (!r.ok) {
    if (j.code === "FEE_CHANGED") feeCache.clear(); // the next tap signs with the new fee
    throw new TradeError(j.error || "Something went wrong. Please try again.");
  }
  return j as Relayed;
}

/** The relayer waits for the block and returns the receipt logs, so no extra round trips here. */
async function confirm(n: Net, res: Relayed): Promise<{ logs: Relayed["logs"]; transactionHash: Hex }> {
  if (res.logs && res.status) {
    if (res.status !== "success") throw new TradeError("The transaction failed on-chain. Your funds are safe.");
    return { logs: res.logs, transactionHash: res.hash };
  }
  const rc = await client(n.id).waitForTransactionReceipt({ hash: res.hash, pollingInterval: 250, timeout: 60_000 });
  if (rc.status !== "success") throw new TradeError("The transaction failed on-chain. Your funds are safe.");
  return { logs: rc.logs as never, transactionHash: rc.transactionHash };
}

/** One-time approval by signature (no gas): lets the router move this token when the user signs a trade. */
const permitted = new Set<string>();
/**
 * The EIP-712 "version" a token uses for permits differs between tokens (Circle USDC: "2",
 * most others: "1"). Pick the one whose domain matches the token's own DOMAIN_SEPARATOR.
 */
const versions = new Map<string, string>();
export async function permitVersion(chainId: number, token: Address): Promise<string> {
  const key = `${chainId}:${token}`.toLowerCase();
  const hit = versions.get(key);
  if (hit) return hit;
  const c = client(chainId);
  const [name, onchain, declared] = await Promise.all([
    c.readContract({ address: token, abi: ERC20, functionName: "name" }),
    c.readContract({ address: token, abi: parseAbi(["function DOMAIN_SEPARATOR() view returns (bytes32)"]), functionName: "DOMAIN_SEPARATOR" }).catch(() => null),
    c.readContract({ address: token, abi: ERC20, functionName: "version" }).catch(() => null),
  ]);
  const tries = [...new Set([declared, "1", "2"].filter(Boolean) as string[])];
  const found = onchain ? tries.find((v) => domainSeparator({ domain: { name, version: v, chainId, verifyingContract: token } }) === onchain) : undefined;
  const v = found ?? declared ?? "1";
  versions.set(key, v);
  return v;
}

async function ensureAllowance(n: Net, s: Signer, token: Address, need: bigint) {
  const key = `${n.id}:${token}:${s.address}`.toLowerCase();
  if (permitted.has(key)) return;
  const c = client(n.id);
  const allowance = await c.readContract({ address: token, abi: ERC20, functionName: "allowance", args: [s.address, n.router] });
  if (allowance >= need) { permitted.add(key); return; }
  if (n.approvals === "gas") {
    // No permit on this network's dollar (BNB): ArkhamPad tops the wallet up with a little gas,
    // then the wallet approves once. The user never sees or pays any gas themselves.
    if (!s.sendTx) throw new TradeError("This wallet can't approve on this network yet.");
    await relay({ chainId: n.id, kind: "gas", user: s.address, token });
    const hash = await s.sendTx(n.id, { to: token, data: encodeFunctionData({ abi: parseAbi(["function approve(address,uint256) returns (bool)"]), functionName: "approve", args: [n.router, MAX] }) });
    await c.waitForTransactionReceipt({ hash, pollingInterval: 250, timeout: 60_000 });
    const ok = await c.readContract({ address: token, abi: ERC20, functionName: "allowance", args: [s.address, n.router] });
    if (ok < need) throw new TradeError("Approval didn't go through. Please try again.");
    permitted.add(key);
    return;
  }
  const [name, nonce, version] = await Promise.all([
    c.readContract({ address: token, abi: ERC20, functionName: "name" }),
    c.readContract({ address: token, abi: ERC20, functionName: "nonces", args: [s.address] }),
    permitVersion(n.id, token),
  ]);
  const dl = deadline();
  const signature = await s.signTypedData(n.id, { domain: { name, version, chainId: n.id, verifyingContract: token }, types: { Permit: TYPES.Permit }, primaryType: "Permit", message: { owner: s.address, spender: n.router, value: MAX, nonce, deadline: dl } });
  await confirm(n, await relay({ chainId: n.id, kind: "permit", token, owner: s.address, value: S(MAX), deadline: S(dl), signature }));
  const after = await c.readContract({ address: token, abi: ERC20, functionName: "allowance", args: [s.address, n.router] });
  if (after < need) throw new TradeError("Approval didn't go through. Please try again.");
  permitted.add(key);
}

/** Signs the coin's one-time sell approval right after a buy, in the background. */
function prepareSell(n: Net, s: Signer, coin: Address) {
  setTimeout(() => { ensureAllowance(n, s, coin, 1n).catch(() => {}); }, 300);
}

// ---------------------------------------------------------------- reads
export async function usdcBalance(chainId: number, who: Address) {
  const n = netOf(chainId);
  if (!n) return 0n;
  return down(n, await client(chainId).readContract({ address: n.usdc, abi: ERC20, functionName: "balanceOf", args: [who] }));
}
export async function tokenBalance(chainId: number, token: Address, who: Address) {
  return client(chainId).readContract({ address: token, abi: ERC20, functionName: "balanceOf", args: [who] });
}
export async function quoteBuy(chainId: number, curve: Address, usdcIn: bigint) {
  const n = netOf(chainId);
  return client(chainId).readContract({ address: curve, abi: CURVE, functionName: "quoteBuy", args: [n ? up(n, usdcIn) : usdcIn] });
}
export async function quoteSell(chainId: number, curve: Address, coins: bigint) {
  const n = netOf(chainId);
  const raw = await client(chainId).readContract({ address: curve, abi: CURVE, functionName: "quoteSell", args: [coins] });
  return n ? down(n, raw) : raw;
}

export type LocalTrade = { chainId: number; coin: Address; curve: Address; trader: Address; isBuy: boolean; usdc: number; coins: number; price: number; mc: number; hash: Hex; at: number };

function tradeFrom(n: Net, rc: { logs: { address: Address; data: Hex; topics: [Hex, ...Hex[]] | [] }[]; transactionHash: Hex }, curve: Address, coin: Address, user: Address): LocalTrade | null {
  const ev = parseEventLogs({ abi: CURVE, logs: rc.logs as never, eventName: "Trade" }).find((e) => e.address.toLowerCase() === curve.toLowerCase());
  if (!ev) return null;
  const a = ev.args as { isBuy: boolean; usdcAmount: bigint; coinAmount: bigint; vUsdcAfter: bigint; vCoinAfter: bigint };
  const price = fromUsdc(down(n, a.vUsdcAfter)) / fromCoin(a.vCoinAfter);
  return { chainId: n.id, coin, curve, trader: user, isBuy: a.isBuy, usdc: fromUsdc(down(n, a.usdcAmount)), coins: fromCoin(a.coinAmount), price, mc: price * 1e9, hash: rc.transactionHash, at: Date.now() };
}

// Trades made in this tab, so pages update instantly (before the indexer catches up).
type Listener = (t: LocalTrade) => void;
const listeners = new Set<Listener>();
export function onLocalTrade(fn: Listener) { listeners.add(fn); return () => { listeners.delete(fn); }; }
const emit = (t: LocalTrade | null) => { if (t) listeners.forEach((f) => f(t)); };

// ---------------------------------------------------------------- actions
const SLIPPAGE_BPS = 300n; // 3%

export async function buy(chainId: number, curve: Address, coin: Address, usdcIn: bigint, s: Signer) {
  const n = netOf(chainId);
  if (!n) throw new TradeError("Unknown network");
  if (usdcIn <= 0n) throw new TradeError("Enter an amount.");
  const fee = await netFee(chainId, "buy");
  const [bal, quote] = await Promise.all([usdcBalance(chainId, s.address), quoteBuy(chainId, curve, usdcIn), ensureAllowance(n, s, n.usdc, up(n, usdcIn + fee))]);
  if (bal < usdcIn + fee) throw new TradeError("Not enough USDC on this network.");
  if (quote === 0n) throw new TradeError("Amount is too small.");
  const minOut = (quote * (10_000n - SLIPPAGE_BPS)) / 10_000n;
  const nonce = randomNonce(), dl = deadline();
  const signature = await s.signTypedData(n.id, { domain: routerDomain(n), types: { Buy: TYPES.Buy }, primaryType: "Buy", message: { user: s.address, curve, usdcIn: up(n, usdcIn), minCoinsOut: minOut, fee: up(n, fee), nonce, deadline: dl } });
  const rc = await confirm(n, await relay({ chainId: n.id, kind: "buy", user: s.address, curve, usdcIn: S(up(n, usdcIn)), minCoinsOut: S(minOut), fee: S(up(n, fee)), nonce: S(nonce), deadline: S(dl), signature }));
  const t = tradeFrom(n, rc as never, curve, coin, s.address);
  emit(t);
  prepareSell(n, s, coin);
  return t;
}

export async function sell(chainId: number, curve: Address, coin: Address, coinAmount: bigint, s: Signer) {
  const n = netOf(chainId);
  if (!n) throw new TradeError("Unknown network");
  if (coinAmount <= 0n) throw new TradeError("Enter an amount.");
  const [held, quote, fee] = await Promise.all([tokenBalance(chainId, coin, s.address), quoteSell(chainId, curve, coinAmount), netFee(chainId, "sell"), ensureAllowance(n, s, coin, coinAmount)]);
  if (held < coinAmount) throw new TradeError("You don't hold that many.");
  if (quote <= fee) throw new TradeError("This sale is too small to cover the network fee.");
  const net = quote - fee;
  const minOut = (net * (10_000n - SLIPPAGE_BPS)) / 10_000n;
  const nonce = randomNonce(), dl = deadline();
  const signature = await s.signTypedData(n.id, { domain: routerDomain(n), types: { Sell: TYPES.Sell }, primaryType: "Sell", message: { user: s.address, curve, coinAmount, minUsdcOut: up(n, minOut), fee: up(n, fee), nonce, deadline: dl } });
  const rc = await confirm(n, await relay({ chainId: n.id, kind: "sell", user: s.address, curve, coinAmount: S(coinAmount), minUsdcOut: S(up(n, minOut)), fee: S(up(n, fee)), nonce: S(nonce), deadline: S(dl), signature }));
  const t = tradeFrom(n, rc as never, curve, coin, s.address);
  emit(t);
  return t;
}

/** Graduated coins: what a pool trade gives right now (simulated on-chain, exact). */
export async function quotePool(chainId: number, coin: Address, isBuy: boolean, amountIn: bigint) {
  const n = netOf(chainId);
  if (!n) return 0n;
  const { result } = await client(chainId).simulateContract({ address: n.router, abi: ROUTER_VIEW, functionName: "quotePool", args: [coin, isBuy, isBuy ? up(n, amountIn) : amountIn] });
  return isBuy ? (result as bigint) : down(n, result as bigint);
}

function poolTradeFrom(n: Net, rc: { logs: unknown[]; transactionHash: Hex }, coin: Address, user: Address): LocalTrade | null {
  const ev = parseEventLogs({ abi: POOL_EVENT, logs: rc.logs as never, eventName: "PoolTraded" })[0];
  if (!ev) return null;
  const a = ev.args as { isBuy: boolean; usdcAmount: bigint; coinAmount: bigint };
  const usdcN = fromUsdc(down(n, a.usdcAmount)), coinsN = fromCoin(a.coinAmount);
  const price = coinsN > 0 ? usdcN / coinsN : 0; // average fill price of this trade
  return { chainId: n.id, coin, curve: coin, trader: user, isBuy: a.isBuy, usdc: usdcN, coins: coinsN, price, mc: price * 1e9, hash: rc.transactionHash, at: Date.now() };
}

export async function poolBuy(chainId: number, coin: Address, usdcIn: bigint, s: Signer) {
  const n = netOf(chainId);
  if (!n) throw new TradeError("Unknown network");
  if (usdcIn <= 0n) throw new TradeError("Enter an amount.");
  const fee = await netFee(chainId, "poolBuy");
  const [bal, quote] = await Promise.all([usdcBalance(chainId, s.address), quotePool(chainId, coin, true, usdcIn), ensureAllowance(n, s, n.usdc, up(n, usdcIn + fee))]);
  if (bal < usdcIn + fee) throw new TradeError("Not enough USDC on this network.");
  if (quote === 0n) throw new TradeError("Amount is too small.");
  const minOut = (quote * (10_000n - SLIPPAGE_BPS)) / 10_000n;
  const nonce = randomNonce(), dl = deadline();
  const signature = await s.signTypedData(n.id, { domain: routerDomain(n), types: { PoolBuy: TYPES.PoolBuy }, primaryType: "PoolBuy", message: { user: s.address, coin, usdcIn: up(n, usdcIn), minCoinsOut: minOut, fee: up(n, fee), nonce, deadline: dl } });
  const rc = await confirm(n, await relay({ chainId: n.id, kind: "poolBuy", user: s.address, coin, usdcIn: S(up(n, usdcIn)), minCoinsOut: S(minOut), fee: S(up(n, fee)), nonce: S(nonce), deadline: S(dl), signature }));
  const t = poolTradeFrom(n, rc as never, coin, s.address);
  emit(t);
  prepareSell(n, s, coin);
  return t;
}

export async function poolSell(chainId: number, coin: Address, coinAmount: bigint, s: Signer) {
  const n = netOf(chainId);
  if (!n) throw new TradeError("Unknown network");
  if (coinAmount <= 0n) throw new TradeError("Enter an amount.");
  const [held, quote, fee] = await Promise.all([tokenBalance(chainId, coin, s.address), quotePool(chainId, coin, false, coinAmount), netFee(chainId, "poolSell"), ensureAllowance(n, s, coin, coinAmount)]);
  if (held < coinAmount) throw new TradeError("You don't hold that many.");
  if (quote <= fee) throw new TradeError("This sale is too small to cover the network fee.");
  const minOut = ((quote - fee) * (10_000n - SLIPPAGE_BPS)) / 10_000n;
  const nonce = randomNonce(), dl = deadline();
  const signature = await s.signTypedData(n.id, { domain: routerDomain(n), types: { PoolSell: TYPES.PoolSell }, primaryType: "PoolSell", message: { user: s.address, coin, coinAmount, minUsdcOut: up(n, minOut), fee: up(n, fee), nonce, deadline: dl } });
  const rc = await confirm(n, await relay({ chainId: n.id, kind: "poolSell", user: s.address, coin, coinAmount: S(coinAmount), minUsdcOut: S(up(n, minOut)), fee: S(up(n, fee)), nonce: S(nonce), deadline: S(dl), signature }));
  const t = poolTradeFrom(n, rc as never, coin, s.address);
  emit(t);
  return t;
}

export type LaunchInput = { name: string; symbol: string; metadataURI: string; lockSeconds: number; feeMode: 0 | 1; launchUsdc: bigint };
export async function launch(chainId: number, l: LaunchInput, s: Signer): Promise<{ coin: Address; curve: Address }> {
  const n = netOf(chainId);
  if (!n) throw new TradeError("Unknown network");
  const fee = await netFee(chainId, "launch");
  const need = l.launchUsdc + fee;
  const bal = await usdcBalance(chainId, s.address);
  if (bal < need) throw new TradeError(`You need at least $${fromUsdc(need).toFixed(2)} USDC on ${n.short} to launch.`);
  await ensureAllowance(n, s, n.usdc, up(n, need));
  const nonce = randomNonce(), dl = deadline();
  const message = { user: s.address, name: l.name, symbol: l.symbol, metadataURI: l.metadataURI, lockSeconds: BigInt(l.lockSeconds), feeMode: l.feeMode, launchUsdc: up(n, l.launchUsdc), minCoinsOut: 0n, fee: up(n, fee), nonce, deadline: dl };
  const signature = await s.signTypedData(n.id, { domain: routerDomain(n), types: { Create: TYPES.Create }, primaryType: "Create", message });
  const rc = await confirm(n, await relay({ chainId: n.id, kind: "launch", user: s.address, launch: { name: l.name, symbol: l.symbol, metadataURI: l.metadataURI, lockSeconds: String(l.lockSeconds), feeMode: l.feeMode, launchUsdc: S(up(n, l.launchUsdc)), minCoinsOut: "0" }, fee: S(up(n, fee)), nonce: S(nonce), deadline: S(dl), signature }));
  const ev = parseEventLogs({ abi: HUB, logs: rc.logs as never, eventName: "CoinCreated" })[0];
  if (!ev) throw new TradeError("Launch went through but the coin wasn't found. Check your profile.");
  const a = ev.args as { coin: Address; curve: Address };
  if (l.launchUsdc > 0n) emit(tradeFrom(n, rc as never, a.curve, a.coin, s.address));
  return { coin: a.coin, curve: a.curve };
}

export async function withdraw(chainId: number, to: Address, amount: bigint, s: Signer) {
  const n = netOf(chainId);
  if (!n) throw new TradeError("Unknown network");
  if (amount <= 0n) throw new TradeError("Enter an amount.");
  const [bal, fee] = await Promise.all([usdcBalance(chainId, s.address), netFee(chainId, "withdraw")]);
  if (bal < amount + fee) throw new TradeError(`Not enough USDC (keep $${fromUsdc(fee).toFixed(2)} for the network fee).`);
  await ensureAllowance(n, s, n.usdc, up(n, amount + fee));
  const nonce = randomNonce(), dl = deadline();
  const signature = await s.signTypedData(n.id, { domain: routerDomain(n), types: { Withdraw: TYPES.Withdraw }, primaryType: "Withdraw", message: { user: s.address, to, amount: up(n, amount), fee: up(n, fee), nonce, deadline: dl } });
  return confirm(n, await relay({ chainId: n.id, kind: "withdraw", user: s.address, to, amount: S(up(n, amount)), fee: S(up(n, fee)), nonce: S(nonce), deadline: S(dl), signature }));
}

export async function promote(chainId: number, coin: Address, plan: 1 | 2 | 3, s: Signer, coinChainId: number = chainId) {
  const n = netOf(chainId);
  if (!n) throw new TradeError("Unknown network");
  const promoter = await client(chainId).readContract({ address: n.router, abi: ROUTER_VIEW, functionName: "promoter" });
  const [, price, active] = await client(chainId).readContract({ address: promoter, abi: PROMOTE, functionName: "plans", args: [plan] });
  if (!active) throw new TradeError("This promotion isn't available right now.");
  const [bal, fee] = await Promise.all([usdcBalance(chainId, s.address), netFee(chainId, "promote")]);
  if (bal < down(n, price) + fee) throw new TradeError("Not enough USDC to promote.");
  await ensureAllowance(n, s, n.usdc, price + up(n, fee));
  const nonce = randomNonce(), dl = deadline();
  const signature = await s.signTypedData(n.id, { domain: routerDomain(n), types: { Promote: TYPES.Promote }, primaryType: "Promote", message: { user: s.address, coin, coinChainId: BigInt(coinChainId), plan, maxPrice: price, fee: up(n, fee), nonce, deadline: dl } });
  return confirm(n, await relay({ chainId: n.id, kind: "promote", user: s.address, coin, coinChainId: String(coinChainId), plan: String(plan), maxPrice: S(price), fee: S(up(n, fee)), nonce: S(nonce), deadline: S(dl), signature }));
}

export async function faucet(chainId: number, to: Address) {
  const n = netOf(chainId);
  if (!n?.faucet) throw new TradeError("No test USDC faucet on this network.");
  return confirm(n, await relay({ chainId, kind: "faucet", to }));
}

/** A coin we launched seconds ago may not be in the database yet: read it from the chain. */
export async function coinFromChain(chainId: number, coin: Address) {
  const n = netOf(chainId);
  if (!n) return null;
  const c = client(chainId);
  const curve = await c.readContract({ address: n.hub, abi: HUB, functionName: "curveOf", args: [coin] });
  if (!curve || /^0x0+$/.test(curve)) return null;
  const [name, symbol, creator, vUsdc, vCoin, reserve, phase] = await Promise.all([
    c.readContract({ address: coin, abi: ERC20, functionName: "name" }),
    c.readContract({ address: coin, abi: ERC20, functionName: "symbol" }),
    c.readContract({ address: curve, abi: CURVE, functionName: "creator" }),
    c.readContract({ address: curve, abi: CURVE, functionName: "vUsdc" }),
    c.readContract({ address: curve, abi: CURVE, functionName: "vCoin" }),
    c.readContract({ address: curve, abi: CURVE, functionName: "usdcReserve" }),
    c.readContract({ address: curve, abi: CURVE, functionName: "phase" }),
  ]);
  const price = fromUsdc(down(n, vUsdc)) / fromCoin(vCoin);
  return { chain_id: chainId, address: coin.toLowerCase(), curve: curve.toLowerCase(), creator: creator.toLowerCase(), name, symbol, phase: Number(phase), price_usd: price, mc_usd: price * 1e9, start_mc_usd: chainId === 84532 || chainId === 46630 ? 450 : 4500, usdc_reserve: fromUsdc(down(n, reserve)), trades_count: 0, created_at: new Date().toISOString(), volume_24h: 0, change_24h_pct: null, buyers: 0, metadata_uri: "" };
}


// ---------------------------------------------------------------- creator tools & upkeep

export async function creatorFeesOf(chainId: number, curve: Address) {
  const c = client(chainId);
  const [fees, mode] = await Promise.all([
    c.readContract({ address: curve, abi: CURVE, functionName: "creatorFees" }),
    c.readContract({ address: curve, abi: CURVE, functionName: "feeMode" }),
  ]);
  const n = netOf(chainId);
  return { fees: n ? down(n, fees) : fees, mode: Number(mode) };
}

/** Pays the creator (or buys back and burns) the fees a curve holds. Anyone can trigger it. */
export async function settleFees(chainId: number, curve: Address) {
  const n = netOf(chainId);
  if (!n) throw new TradeError("Unknown network");
  return confirm(n, await relay({ chainId, kind: "settle", curve }));
}
/** Graduated coins: collect the locked pool's trading fees (70% platform, 30% creator or buyback). */
export async function collectPoolFees(chainId: number, coin: Address) {
  const n = netOf(chainId);
  if (!n) throw new TradeError("Unknown network");
  return confirm(n, await relay({ chainId, kind: "collect", coin }));
}
export async function runBuyback(chainId: number, coin: Address) {
  const n = netOf(chainId);
  if (!n) throw new TradeError("Unknown network");
  return confirm(n, await relay({ chainId, kind: "buyback", coin }));
}

/** Resizes to a 256px square WebP, signs it as the creator and uploads it. Returns the image URL. */
export async function uploadCoinImage(chainId: number, coin: Address, file: File, s: Signer): Promise<string> {
  const n = netOf(chainId);
  if (!n) throw new TradeError("Unknown network");
  if (!/^image\/(png|jpe?g|webp|gif)$/.test(file.type)) throw new TradeError("Use a PNG, JPG or WebP image.");
  if (file.size > 10_000_000) throw new TradeError("Image is too large (max 10 MB).");
  const dataUrl = await squareImage(file, 256);
  const bytes = Uint8Array.from(atob(dataUrl.split(",")[1]), (ch) => ch.charCodeAt(0));
  const signature = await s.signTypedData(chainId, {
    domain: routerDomain(n),
    types: { CoinImage: [{ name: "coin", type: "address" }, { name: "imageHash", type: "bytes32" }] },
    primaryType: "CoinImage",
    message: { coin, imageHash: keccak256(bytes) },
  });
  let r: Response;
  try {
    r = await fetch(`${RELAYER}/image`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ chainId, coin, dataUrl, signature }) });
  } catch { throw new TradeError("Can't reach ArkhamPad right now. Check your connection."); }
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new TradeError(j.error || "Upload failed, please try again.");
  return j.url as string;
}

export function squareImage(file: File, size: number): Promise<string> {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const cv = document.createElement("canvas");
      cv.width = size; cv.height = size;
      const ctx = cv.getContext("2d");
      if (!ctx) { rej(new TradeError("Couldn't read the image.")); return; }
      const side = Math.min(img.width, img.height); // centre crop to a square
      ctx.drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, size, size);
      URL.revokeObjectURL(url);
      let out = cv.toDataURL("image/webp", 0.86);
      if (!out.startsWith("data:image/webp")) out = cv.toDataURL("image/png");
      res(out);
    };
    img.onerror = () => { URL.revokeObjectURL(url); rej(new TradeError("Couldn't read the image.")); };
    img.src = url;
  });
}

/** Biggest holders, from everyone who ever bought plus the creator, read live from the chain. */
export async function holdersOf(chainId: number, coin: Address, wallets: string[]) {
  const c = client(chainId);
  const uniq = [...new Set(wallets.map((w) => w.toLowerCase()))].slice(0, 200);
  const rows: { wallet: string; amount: number }[] = [];
  for (let i = 0; i < uniq.length; i += 25) {
    const part = await Promise.all(uniq.slice(i, i + 25).map(async (w) => ({ wallet: w, amount: fromCoin(await c.readContract({ address: coin, abi: ERC20, functionName: "balanceOf", args: [w as Address] }).catch(() => 0n)) })));
    rows.push(...part.filter((r) => r.amount > 0));
  }
  return rows.sort((a, b) => b.amount - a.amount);
}

// ---------------------------------------------------------------- automatic orders

export type OrderKind = "limit_buy" | "take_profit" | "stop_loss";
export type Order = { id: string; chain_id: number; coin: string; kind: OrderKind; venue: "curve" | "pool"; trigger_mc: number; amount: string; nonce: string; status: string; note: string | null; tx_hash: string | null; created_at: string; deadline: string };

/**
 * Signs a trade now that the relayer sends later, when the market cap reaches `triggerMc`.
 * The signed minimum (how much the user gets at worst) is set from the trigger price, so the
 * order can never fill at a much worse price than the user chose.
 */
export async function placeOrder(p: { chainId: number; coin: Address; curve: Address | null; pool: boolean; kind: OrderKind; triggerMc: number; amount: bigint }, s: Signer) {
  const n = netOf(p.chainId);
  if (!n) throw new TradeError("Unknown network");
  if (p.amount <= 0n) throw new TradeError("Enter an amount.");
  if (!(p.triggerMc > 0)) throw new TradeError("Pick a market cap.");
  const isBuy = p.kind === "limit_buy";
  // orders fill later, maybe when gas is higher: they carry twice today's fee
  const fee = (await netFee(p.chainId, p.pool ? (isBuy ? "poolBuy" : "poolSell") : (isBuy ? "buy" : "sell"))) * 2n;
  const price = p.triggerMc / 1e9; // USDC per coin at the trigger
  let min: bigint;
  if (isBuy) {
    // coins for usdcIn at the trigger price, after the 1% fee, with 3% room
    min = BigInt(Math.floor((fromUsdc(p.amount) * 0.99 / price) * 0.97 * 1e6)) * 10n ** 12n;
  } else {
    // stop loss gets more room (prices fall fast); take profit sells at or above the target
    const room = p.kind === "stop_loss" ? 0.8 : 0.96;
    const v = fromCoin(p.amount) * price * 0.99 * room - fromUsdc(fee);
    min = up(n, BigInt(Math.max(1, Math.floor(v * 1e6))));
  }
  await ensureAllowance(n, s, isBuy ? n.usdc : p.coin, isBuy ? up(n, p.amount + fee) : p.amount);
  const nonce = randomNonce();
  const dl = BigInt(Math.floor(Date.now() / 1000) + 30 * 86400); // valid for 30 days
  const venue = p.pool ? "pool" : "curve";
  const reqKind = p.pool ? (isBuy ? "poolBuy" : "poolSell") : (isBuy ? "buy" : "sell");
  const types = { buy: TYPES.Buy, sell: TYPES.Sell, poolBuy: TYPES.PoolBuy, poolSell: TYPES.PoolSell }[reqKind];
  const primary = { buy: "Buy", sell: "Sell", poolBuy: "PoolBuy", poolSell: "PoolSell" }[reqKind];
  const target = p.pool ? { coin: p.coin } : { curve: p.curve as Address };
  const message = isBuy
    ? { user: s.address, ...target, usdcIn: up(n, p.amount), minCoinsOut: min, fee: up(n, fee), nonce, deadline: dl }
    : { user: s.address, ...target, coinAmount: p.amount, minUsdcOut: min, fee: up(n, fee), nonce, deadline: dl };
  const signature = await s.signTypedData(n.id, { domain: routerDomain(n), types: { [primary]: types }, primaryType: primary, message });
  const request = { kind: reqKind, ...Object.fromEntries(Object.entries(message).map(([k, v]) => [k, typeof v === "bigint" ? v.toString() : v])), signature };
  let r: Response;
  try { r = await fetch(`${RELAYER}/orders`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ chainId: n.id, kind: p.kind, coin: p.coin, triggerMc: p.triggerMc, request }) }); }
  catch { throw new TradeError("Can't reach ArkhamPad right now. Check your connection."); }
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new TradeError(j.error || "Couldn't place the order.");
  void venue;
  return j.id as string;
}

// ---- private reads (your orders and inbox): one signature per day per wallet, then a token
const sessions = new Map<string, { token: string; exp: number }>();
const pendingSession = new Map<string, Promise<string | null>>();
export async function readToken(s: Signer | null): Promise<string | null> {
  if (!s) return null;
  const k = s.address.toLowerCase();
  const now = Date.now() / 1000;
  let have = sessions.get(k);
  if (!have) { try { const raw = sessionStorage.getItem(`ap_sess_${k}`); if (raw) have = JSON.parse(raw); } catch { /* private mode */ } }
  if (have && have.exp - 120 > now) { sessions.set(k, have); return have.token; }
  if (pendingSession.has(k)) return pendingSession.get(k)!;
  const p = (async () => {
    try {
      const time = BigInt(Math.floor(now));
      const payload = {};
      const hash = keccak256(new TextEncoder().encode(JSON.stringify(payload)));
      const signature = await s.signTypedData(NETS[0].id, { domain: { name: "ArkhamPad", version: "1" }, types: { Request: [{ name: "action", type: "string" }, { name: "payload", type: "bytes32" }, { name: "time", type: "uint256" }] }, primaryType: "Request", message: { action: "session", payload: hash, time } });
      const r = await fetch(`${RELAYER}/session`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ user: s.address, action: "session", payload, time: time.toString(), signature }) });
      if (!r.ok) return null;
      const j = (await r.json()) as { token: string; exp: number };
      sessions.set(k, j);
      try { sessionStorage.setItem(`ap_sess_${k}`, JSON.stringify(j)); } catch { /* private mode */ }
      return j.token;
    } catch { return null; } finally { pendingSession.delete(k); }
  })();
  pendingSession.set(k, p);
  return p;
}
const dropToken = (s: Signer) => { const k = s.address.toLowerCase(); sessions.delete(k); try { sessionStorage.removeItem(`ap_sess_${k}`); } catch { /* */ } };

export async function myOrders(s: Signer | null): Promise<Order[]> {
  const token = await readToken(s);
  if (!token || !s) return [];
  const r = await fetch(`${RELAYER}/orders?token=${encodeURIComponent(token)}`).catch(() => null);
  if (r?.status === 401) dropToken(s);
  if (!r || !r.ok) return [];
  return r.json();
}

export async function cancelOrder(o: Order, s: Signer) {
  const n = netOf(o.chain_id);
  if (!n) throw new TradeError("Unknown network");
  const signature = await s.signTypedData(n.id, { domain: routerDomain(n), types: { Cancel: [{ name: "user", type: "address" }, { name: "nonce", type: "uint256" }] }, primaryType: "Cancel", message: { user: s.address, nonce: BigInt(o.nonce) } });
  const r = await fetch(`${RELAYER}/orders/cancel`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ id: o.id, signature }) }).catch(() => null);
  const j = r ? await r.json().catch(() => ({})) : {};
  if (!r || !r.ok) throw new TradeError(j.error || "Couldn't cancel the order.");
}

// ---------------------------------------------------------------- follows

export async function setFollow(trader: Address, on: boolean, s: Signer) {
  const time = BigInt(Math.floor(Date.now() / 1000));
  const signature = await s.signTypedData(NETS[0].id, { domain: { name: "ArkhamPad", version: "1" }, types: { Follow: [{ name: "trader", type: "address" }, { name: "on", type: "bool" }, { name: "time", type: "uint256" }] }, primaryType: "Follow", message: { trader, on, time } });
  const r = await fetch(`${RELAYER}/follow`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ follower: s.address, trader, on, time: time.toString(), signature }) }).catch(() => null);
  const j = r ? await r.json().catch(() => ({})) : {};
  if (!r || !r.ok) throw new TradeError(j.error || "Couldn't update. Please try again.");
}

// ---------------------------------------------------------------- signed account actions (alerts, push, bell)

export async function accountAction(action: string, payload: Record<string, unknown>, s: Signer) {
  const time = BigInt(Math.floor(Date.now() / 1000));
  const hash = keccak256(new TextEncoder().encode(JSON.stringify(payload)));
  const signature = await s.signTypedData(NETS[0].id, { domain: { name: "ArkhamPad", version: "1" }, types: { Request: [{ name: "action", type: "string" }, { name: "payload", type: "bytes32" }, { name: "time", type: "uint256" }] }, primaryType: "Request", message: { action, payload: hash, time } });
  const r = await fetch(`${RELAYER}/action`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ user: s.address, action, payload, time: time.toString(), signature }) }).catch(() => null);
  const j = r ? await r.json().catch(() => ({})) : {};
  if (!r || !r.ok) throw new TradeError(j.error || "Something went wrong. Please try again.");
  return j;
}

export type Note = { id: string; kind: string; title: string; body: string; url: string; read: boolean; created_at: string };
export type PriceAlert = { id: string; chain_id: number; coin: string; tick: string; direction: "above" | "below"; target_mc: number; status: string; created_at: string; hit_at: string | null };
export async function inbox(s: Signer | null): Promise<{ notes: Note[]; unread: number; alerts: PriceAlert[] }> {
  const token = await readToken(s);
  if (!token || !s) return { notes: [], unread: 0, alerts: [] };
  const r = await fetch(`${RELAYER}/inbox?token=${encodeURIComponent(token)}`).catch(() => null);
  if (r?.status === 401) dropToken(s);
  if (!r || !r.ok) return { notes: [], unread: 0, alerts: [] };
  return r.json();
}
export async function vapidKey(): Promise<string | null> {
  const r = await fetch(`${RELAYER}/config`).catch(() => null);
  const j = r ? await r.json().catch(() => ({})) : {};
  return j.vapidPublicKey ?? null;
}


/** Dev wallet (local tests): send a transaction with a plain private-key account. */
export async function sendWithAccount(account: import("viem").Account, chainId: number, tx: { to: Address; data: Hex }) {
  const n = netOf(chainId);
  if (!n) throw new TradeError("Unknown network");
  const chain = defineChain({ id: n.id, name: n.name, nativeCurrency: { name: "ETH", symbol: "ETH", decimals: 18 }, rpcUrls: { default: { http: [n.rpc] } } });
  return createWalletClient({ account, chain, transport: http(n.rpc) }).sendTransaction({ account, to: tx.to, data: tx.data, chain });
}
