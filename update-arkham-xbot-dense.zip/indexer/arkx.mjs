// @Arkhampad on X: an auto-poster that tweets ArkhamPad's own updates on a schedule.
// It posts on its own timeline only; it never replies to, follows or reads anyone else.
//
// Goal: pull people who trade (or want to trade) on Elysium over to ArkhamPad. Every post is a
// FOMO / curiosity hook about the opportunity of trading on Elysium and ArkhamPad's edge — trade
// any Elysium coin with USDC OR HYPE, smart-money signals, and rug/safety checks, all in one place.
// Every post features the ArkhamPad brand, links arkhampad.com, and uses a DIFFERENT, heavy hashtag
// set. About 30% of the day's posts tag an Elysium account (@Enter_Elysium / @HyperliquidX) — never
// a competitor. No made-up numbers, no "mainnet soon".
//
// Runs as its own Railway service: root /indexer, start command `node arkx.mjs`.
// Env:
//   ARK_X_API_KEY, ARK_X_API_SECRET, ARK_X_ACCESS_TOKEN, ARK_X_ACCESS_SECRET
//       the @Arkhampad app's OAuth 1.0a keys (console.x.com). Without all four this does nothing.
//   DATABASE_URL     the same Postgres as the indexer (used only to remember what was posted)
//   ARK_X_OFF=1      switch off          ARK_X_DRY=1   log what it would post, post nothing
//
// Schedule (Türkiye time, UTC+3): mornings ~06:00–12:45 roughly every 45 min, then evenings
// ~15:15–22:40 roughly every 45 min. Each slot is moved by a fixed ±12 min per day, so posts never
// go out at the same minute two days running. A line is not reused until every other line has been
// posted (a 10-day no-repeat window in the database), so text and hashtags change every time.

import { createHmac, randomBytes } from "node:crypto";
import { readFileSync } from "node:fs";
import pg from "pg";
import { buildResponse, QUERIES } from "./scout-engine.mjs";
import { writePost } from "./esask.mjs";

const TR = 3 * 3600e3;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const log = (...a) => console.log(new Date().toISOString(), "arkx:", ...a);

// ------------------------------------------------------------------ X API (OAuth 1.0a, user context)
const API = "https://api.x.com";
const enc = (s) => encodeURIComponent(s).replace(/[!'()*]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`);

function oauthHeader(method, url, keys, nonce = randomBytes(16).toString("hex"), ts = Math.floor(Date.now() / 1000)) {
  const o = {
    oauth_consumer_key: keys.apiKey,
    oauth_nonce: nonce,
    oauth_signature_method: "HMAC-SHA1",
    oauth_timestamp: String(ts),
    oauth_token: keys.accessToken,
    oauth_version: "1.0",
  };
  const u = new URL(url);
  const params = [...Object.entries(o), ...u.searchParams.entries()]
    .map(([k, v]) => [enc(k), enc(v)])
    .sort((a, b) => (a[0] === b[0] ? (a[1] < b[1] ? -1 : 1) : a[0] < b[0] ? -1 : 1));
  const base = [method.toUpperCase(), enc(`${u.origin}${u.pathname}`), enc(params.map(([k, v]) => `${k}=${v}`).join("&"))].join("&");
  const sig = createHmac("sha1", `${enc(keys.apiSecret)}&${enc(keys.accessSecret)}`).update(base).digest("base64");
  return "OAuth " + Object.entries({ ...o, oauth_signature: sig }).map(([k, v]) => `${enc(k)}="${enc(v)}"`).join(", ");
}

async function postTweet(keys, text, replyTo = null) {
  const url = `${API}/2/tweets`;
  const r = await fetch(url, {
    method: "POST",
    headers: { authorization: oauthHeader("POST", url, keys), "content-type": "application/json" },
    body: JSON.stringify({ text, ...(replyTo ? { reply: { in_reply_to_tweet_id: replyTo } } : {}) }),
  });
  const body = await r.text();
  if (!r.ok) throw new Error(`X /2/tweets ${r.status}: ${body.slice(0, 300)}`);
  try { return JSON.parse(body)?.data?.id ?? null; } catch { return null; }
}

/** An image for a post (PNG bytes): X's v2 media upload, the older v1.1 endpoint as a fallback. */
async function uploadImage(keys, buf) {
  const tries = [
    ["https://api.x.com/2/media/upload", (j) => j?.data?.id ?? j?.id ?? j?.media_id_string],
    ["https://upload.twitter.com/1.1/media/upload.json", (j) => j?.media_id_string],
  ];
  let last;
  for (const [url, pick] of tries) {
    try {
      const fd = new FormData();
      fd.append("media", new Blob([buf], { type: "image/png" }), "card.png");
      fd.append("media_category", "tweet_image");
      const r = await fetch(url, { method: "POST", headers: { authorization: oauthHeader("POST", url, keys) }, body: fd });
      const t = await r.text();
      if (!r.ok) throw new Error(`${url} ${r.status}: ${t.slice(0, 200)}`);
      const id = pick(JSON.parse(t));
      if (id) return String(id);
      throw new Error(`no media id: ${t.slice(0, 200)}`);
    } catch (e) { last = e; }
  }
  throw last;
}

async function postTweetWithImage(keys, text, mediaId) {
  const url = `${API}/2/tweets`;
  const r = await fetch(url, {
    method: "POST",
    headers: { authorization: oauthHeader("POST", url, keys), "content-type": "application/json" },
    body: JSON.stringify({ text, media: { media_ids: [mediaId] } }),
  });
  const body = await r.text();
  if (!r.ok) throw new Error(`X /2/tweets ${r.status}: ${body.slice(0, 300)}`);
  try { return JSON.parse(body)?.data?.id ?? null; } catch { return null; }
}

// ------------------------------------------------------------------ the words
// Each entry is [id, text]. ids are what "not used lately" remembers. FOMO / curiosity hooks aimed
// at Elysium traders, every one featuring ArkhamPad + the arkhampad.com link + its own hashtag set.
// ~30% tag @Enter_Elysium or @HyperliquidX (never a competitor).
const LINK = "arkhampad.com";
function POSTS() {
  return [
    ["a1", `the people making real money on Elysium this week are already trading. are you? 👀\n\nArkhamPad — every Elysium coin, with USDC or HYPE\n\n${LINK}\n\n#Elysium #DeFi #SmartMoney #CryptoTrading #HYPE`],
    ["a2", `new chain, fresh coins, barely any crowd yet\n\ntrade them on ArkhamPad with USDC or HYPE — your call, no bridges\n\n${LINK}\n\n#Elysium #Altcoins #OnChain #Crypto #NewChain #USDC`],
    ["a3", `the smart money is already moving on @Enter_Elysium 👀\n\nArkhamPad shows you who's really buying, before the crowd catches on\n\n${LINK}\n\n#Elysium #SmartMoney #Trading #Web3 #CryptoNews`],
    ["a4", `USDC or HYPE — trade any Elysium coin either way on ArkhamPad. no wrapping, no friction\n\n${LINK}\n\n#Elysium #USDC #HYPE #DeFi #CryptoTrading #Hyperliquid`],
    ["a5", `everyone's about to find out what's trading on @Enter_Elysium 👀\n\nyou can already be in. ArkhamPad, USDC or HYPE\n\n${LINK}\n\n#Elysium #Altcoins #Crypto #OnChain #GEM`],
    ["a6", `Arkham is Elysium's launchpad.\n\nsee who's buying, check it's safe, trade it with USDC or HYPE — all on one page\n\n${LINK}\n\n#Elysium #SmartMoney #RugCheck #DeFi #Trading`],
    ["a7", `the first traders on a new chain are the ones who eat 👀\n\nElysium is early. ArkhamPad lets you trade it now, USDC or HYPE\n\n${LINK}\n\n#Elysium #NewChain #Altcoins #100x #CryptoTrading`],
    ["a8", `rug checks and dev reputation on every coin 👀\n\ntrade Elysium with your eyes open — and with USDC or HYPE — on ArkhamPad\n\n${LINK}\n\n#Elysium #RugCheck #CryptoSafety #DeFi #DYOR`],
    ["a9", `coins are moving on @HyperliquidX's new chain right now while you scroll\n\njump in on ArkhamPad, USDC or HYPE\n\n${LINK}\n\n#Elysium #HYPE #Hyperliquid #Trading #Altcoins`],
    ["a10", `you don't need HYPE to start. trade Elysium coins with USDC too — ArkhamPad handles the rest\n\n${LINK}\n\n#Elysium #USDC #DeFi #Crypto #OnChain #CryptoTrading`],
    ["a11", `the quiet window before a chain gets loud is where the money's made 👀\n\n@Enter_Elysium is in it. trade on ArkhamPad\n\n${LINK}\n\n#Elysium #SmartMoney #Altcoins #GEM #NewChain`],
    ["a12", `Arkham is Elysium's launchpad.\n\ndiscover what's pumping, trade it in one tap — USDC or HYPE, your choice\n\n${LINK}\n\n#Elysium #CryptoTrading #DeFi #Memecoins #HYPE`],
    ["a13", `smart wallets leave a trail. ArkhamPad reads it live so you trade where the money's actually going on Elysium\n\n${LINK}\n\n#Elysium #SmartMoney #OnChain #Trading #Web3`],
    ["a14", `trade the whole chain from one page — every Elysium coin, USDC or HYPE, live prices\n\nArkhamPad\n\n${LINK}\n\n#Elysium #DeFi #CryptoTrading #Altcoins #USDC`],
    ["a15", `@Enter_Elysium is early and wide open 👀\n\nthe traders who show up first win. ArkhamPad, USDC or HYPE\n\n${LINK}\n\n#Elysium #NewChain #Altcoins #100x #CryptoGems`],
    ["a16", `before you ape a coin on Elysium, see its dev's track record and rug score\n\nArkhamPad shows it, then you trade — USDC or HYPE\n\n${LINK}\n\n#Elysium #RugCheck #CryptoSafety #OnChain #Trading`],
    ["a17", `the trade you miss on @Enter_Elysium today is the screenshot you regret next week 👀\n\nArkhamPad. USDC or HYPE\n\n${LINK}\n\n#Elysium #Altcoins #CryptoTrading #GEM #SmartMoney`],
    ["a18", `no bridge marathon, no wrapped tokens. USDC or HYPE straight into any Elysium coin on ArkhamPad\n\n${LINK}\n\n#Elysium #USDC #HYPE #DeFi #OnChain`],
    ["a19", `Arkham is Elysium's launchpad.\n\nwhere the smart money, the safety checks and the trade all live on one page\n\n${LINK}\n\n#Elysium #SmartMoney #RugCheck #Trading #Web3`],
    ["a20", `the money on @HyperliquidX is hunting the next Elysium runner 👀\n\nbe early. trade on ArkhamPad with USDC or HYPE\n\n${LINK}\n\n#Elysium #HYPE #Hyperliquid #SmartMoney #Altcoins`],
    ["a21", `whale buys, sized to each coin, flagged live 👀\n\ntrade the moves that matter on Elysium — ArkhamPad, USDC or HYPE\n\n${LINK}\n\n#Elysium #Whales #SmartMoney #Trading #DeFi`],
    ["a22", `fresh launches on Elysium surface the second they go live on ArkhamPad\n\ncatch them early, trade USDC or HYPE\n\n${LINK}\n\n#Elysium #TokenLaunch #Altcoins #NewChain #CryptoTrading`],
    ["a23", `trading on Elysium shouldn't mean 12 steps. open ArkhamPad, pick USDC or HYPE, go\n\n${LINK}\n\n#Elysium #DeFi #USDC #OnChain #Crypto`],
    ["a24", `@Enter_Elysium coins, all in one place, with the data to trade them right 👀\n\nArkhamPad — USDC or HYPE\n\n${LINK}\n\n#Elysium #Altcoins #SmartMoney #OnChain #Trading`],
    ["a25", `the crowd shows up late, every time 👀\n\nbeat them to Elysium. trade on ArkhamPad with USDC or HYPE\n\n${LINK}\n\n#Elysium #Altcoins #CryptoTrading #GEM #Degens`],
    ["a26", `Arkham is Elysium's launchpad.\n\ntrade any coin with USDC or HYPE, see the smart money, skip the rugs\n\n${LINK}\n\n#Elysium #SmartMoney #RugCheck #HYPE #DeFi`],
    ["a27", `momentum, buy pressure and fresh launches on @Enter_Elysium — ranked live so you know what's moving right now\n\ntrade it on ArkhamPad\n\n${LINK}\n\n#Elysium #SmartMoney #Trading #Altcoins #OnChain`],
    ["a28", `two ways in, one place to trade: USDC or HYPE, every Elysium coin, on ArkhamPad 👀\n\n${LINK}\n\n#Elysium #USDC #HYPE #OnChain #Trading #Memecoins`],
    // Nov 5: create on Elysium + every coin on the chain trades here (new launches too), dev buys/sells on
    // the chart, your position and PnL. These go first (the no-repeat rule picks unused lines first).
    ["b1", `Arkham is Elysium's launchpad.\n\ngot a coin idea? name it, drop a logo, it's live on Elysium in about a minute. no code, email login\n\n${LINK}\n\n#Elysium #CreateToken #Memecoins #HYPE #Web3`],
    ["b2", `every coin launched on Elysium today is tradeable on ArkhamPad. not some of them. all of them 👀\n\n${LINK}\n\n#Elysium #NewCoins #Altcoins #HYPE #Trading`],
    ["b3", `the chart on ArkhamPad now shows exactly when the dev bought and when the dev sold\n\nno more finding out after the dump\n\n${LINK}\n\n#Elysium #DYOR #RugCheck #OnChain #Memecoins`],
    ["b4", `launch your own coin on @Enter_Elysium before the crowd shows up 👀\n\nArkhamPad, one minute, you keep a cut of every trade\n\n${LINK}\n\n#Elysium #TokenLaunch #CreateToken #Crypto #DeFi`],
    ["b5", `bought something on Elysium? ArkhamPad shows your entry, your PnL and the dev's moves on one screen\n\n${LINK}\n\n#Elysium #PnL #CryptoTrading #HYPE #Web3`],
    ["b6", `Arkham is Elysium's launchpad.\n\nthe coins pumping 1000%+ on Elysium right now? you can buy them here in one tap. email login, no seed phrase\n\n${LINK}\n\n#Elysium #100x #Altcoins #Memecoins #Crypto`],
    ["b7", `your coin, your name, your ticker, live on Elysium in 60 seconds 🚀\n\nthen share the link and let it run\n\n${LINK}\n\n#Elysium #LaunchYourCoin #Memecoins #HYPE #DeFi`],
    ["b8", `new coins hit Elysium every few minutes. most die. the ones that run, people saw early 👀\n\nwatch them land live on ArkhamPad\n\n${LINK}\n\n#Elysium #NewChain #GEM #OnChain #Trading`],
    ["b9", `@HyperliquidX's new chain is filling up with coins fast\n\ncreate one or trade them all on ArkhamPad, HYPE or USDC\n\n${LINK}\n\n#Elysium #Hyperliquid #HYPE #Memecoins #CryptoTrading`],
    ["b10", `before you buy: who holds it, did the dev sell, is it sellable at all\n\nArkhamPad checks it on every Elysium coin, then you trade\n\n${LINK}\n\n#Elysium #CryptoSafety #RugCheck #DYOR #DeFi`],
    ["b11", `Arkham is Elysium's launchpad.\n\nmake a coin, trade any coin, see the smart money. that's it, that's the app\n\n${LINK}\n\n#Elysium #Web3 #SmartMoney #CreateToken #HYPE`],
    ["b12", `the crowd on @Enter_Elysium is growing every day 👀\n\nlaunch your coin now and be the one they find. ArkhamPad\n\n${LINK}\n\n#Elysium #TokenLaunch #Altcoins #Crypto #GEM`],
  ];
}

// ------------------------------------------------------------------ creator campaign (Nov 5: the "25K" fee rules)
// 19 posts a day (04:00-10:00 and 16:30-22:00), each with one of 16 images (xcards/creator-1..16.png, 1600x900, every one shows arkhampad.com).
// They go first at their own slots. The post itself carries no link (X shows link posts to fewer people and
// charges more for them); arkhampad.com follows as a reply under it 20-70 s later. ARK_X_CREATOR_LINK=0 drops
// that reply (the image already shows arkhampad.com).
// ARK_X_CREATOR_OFF=1 stops the campaign. The facts, fixed: creators start at 20% of every trade fee; above
// $25K for 1 hour, 50%; above $100K, 60%; in the first 24h an extra 15% is held, paid out if the coin makes it.
const CREATOR_PLAN = [
  // Nov 6: denser in the two windows that matter (Türkiye time): 04:00-10:00 and 16:30-22:00
  "04:00", "04:45", "05:30", "06:15", "07:00", "07:45", "08:30", "09:15", "10:00",
  "16:30", "17:05", "17:40", "18:15", "18:50", "19:25", "20:00", "20:35", "21:10", "21:45",
];
const CREATOR_ON = () => process.env.ARK_X_CREATOR_OFF !== "1";
const card = (n) => readFileSync(new URL(`./xcards/creator-${n}.png`, import.meta.url));
/** [id, text, image number]. */
function CREATOR() {
  return [
    ["c1", `Arkham is Elysium's launchpad.\n\nbig update: get your coin above $25K and you take HALF of every trade fee on it\n\n#Elysium #CreatorFees`, 1],
    ["c2", `launched a coin on Elysium? on ArkhamPad you now earn half of every trade fee once it holds $25K for an hour 👀\n\n#Elysium #Memecoins`, 1],
    ["c3", `quick math for creators: $100K daily volume on your coin = $500 a day to you on ArkhamPad\n\n#Elysium #PassiveIncome`, 2],
    ["c4", `your coin trades, you get paid. half of every fee, every trade, once it's above $25K. that's ArkhamPad now\n\n#Elysium #CryptoCreators`, 2],
    ["c5", `Arkham is Elysium's launchpad.\n\nfirst 24 hours of your coin? we put an extra 15% of every fee aside for you. hit $25K and it's yours\n\n#Elysium #TokenLaunch`, 3],
    ["c6", `the first day matters most. ArkhamPad holds a bonus 15% of fees for every new coin's creator, paid the moment it makes it\n\n#Elysium #LaunchDay`, 3],
    ["c7", `20% at launch. 50% above $25K. 60% above $100K.\n\nthe bigger your coin gets on ArkhamPad, the bigger your cut\n\n#Elysium #Memecoin`, 4],
    ["c8", `your coin can pay you up to 60% of every trade fee on ArkhamPad. the bigger it gets, the more you make\n\n#Elysium #HYPE`, 4],
    ["c9", `the rule is simple on ArkhamPad: $25K market cap for 1 hour = half of every trade fee is yours\n\n#Elysium #DeFi`, 5],
    ["c10", `Arkham is Elysium's launchpad.\n\nhold $25K for an hour and the switch flips: you earn 50% of every trade on your coin\n\n#Elysium #OnChain`, 5],
    ["c11", `launch → pass $25K → earn half of every trade fee\n\nno code, about a minute to launch on ArkhamPad\n\n#Elysium #CreateToken`, 6],
    ["c12", `got a coin idea? ArkhamPad puts it live on Elysium in a minute, and once it holds $25K half the fees are yours\n\n#Elysium #Web3`, 6],
    ["c13", `every coin on ArkhamPad starts around $3.9K. $25K is the line. cross it and half of every trade fee goes to you\n\n#Elysium #Altcoins`, 7],
    ["c14", `who's launching the first coin to cross $25K on ArkhamPad? that creator starts earning half of every trade 👀\n\n#Elysium #Crypto`, 7],
    ["c15", `liquidity locked forever, no team tokens, no presale. and now creators earn up to 60% of fees. ArkhamPad\n\n#Elysium #FairLaunch`, 8],
    ["c16", `Arkham is Elysium's launchpad.\n\nfair launch for your community, real money for you: up to 60% of every trade fee\n\n#Elysium #CryptoTwitter`, 8],
    ["n1", `your coin hits $25K and stays there an hour → you take HALF of every trade fee. most launchpads never offered that. ArkhamPad did\n\n#Elysium #Memecoin #CryptoCreators #Hyperliquid #TokenLaunch`, 9],
    ["n2", `Arkham is Elysium's launchpad.\n\nsomebody is about to launch the first coin past $25K and start collecting half the fees. why not you 👀\n\n#Elysium #Memecoins #Launchpad #HYPE #Web3`, 13],
    ["n3", `think about it: you launch in a minute, no code, and if the coin holds $25K for an hour half of every trade fee lands in your wallet\n\n#Elysium #CreateToken #Crypto #Altcoins #OnChain`, 9],
    ["n4", `$100K market cap on your own coin = 60% of every trade fee. yes, sixty. only on ArkhamPad\n\n#Elysium #CryptoTwitter #Memecoin #CreatorEconomy #HYPE`, 10],
    ["n5", `everyone is trading Elysium coins. almost nobody is launching them. the creators get paid on every single trade 👀 ArkhamPad\n\n#Elysium #Memecoins #Hyperliquid #DeFi #Crypto`, 15],
    ["n6", `20% of fees the second you launch. 50% once you hold $25K for an hour. 60% above $100K. the cut only goes up from here\n\n#Elysium #ArkhamPad #CryptoCreators #Altcoin #Web3`, 11],
    ["n7", `Arkham is Elysium's launchpad.\n\nno presale, no team bags, liquidity locked, and the creator still gets up to 60% of fees. that's the whole pitch\n\n#Elysium #FairLaunch #Memecoin #CryptoNews`, 14],
    ["n8", `got a meme in your head? name, ticker, picture, done. live on Elysium in about a minute. the money part starts at $25K\n\n#Elysium #MemeCoin #LaunchAToken #Crypto #NoCode`, 12],
    ["n9", `every trade on your coin pays you. buys, sells, doesn't matter. fees in HYPE and your own coin. ArkhamPad\n\n#Elysium #PassiveIncome #Memecoins #HYPE #CryptoCreators`, 15],
    ["n10", `first 24 hours of your coin: we quietly set 15% of the fee aside for you. cross $25K and it's all yours\n\n#Elysium #TokenLaunch #Crypto #Altcoins #ArkhamPad`, 16],
    ["n11", `what would you do with half of every trade fee on a coin that blew up? you can find out on ArkhamPad 👀\n\n#Elysium #Memecoin #CryptoDreams #HYPE #Web3`, 9],
    ["n12", `people on @Enter_Elysium keep asking where to launch. ArkhamPad: locked liquidity, creators earn up to 60% of fees\n\n#Elysium #Hyperliquid #Memecoins #Launchpad #Crypto`, 14],
    ["n13", `the first creator to cross $25K on ArkhamPad is going to get a lot of attention. could be you\n\n#Elysium #Memecoin #CryptoTwitter #Altcoins #FirstMover`, 13],
    ["n14", `$3.9K to $25K. that's the gap between a coin that exists and a coin that pays you half the fees\n\n#Elysium #Memecoins #TokenCreators #Crypto #HYPE`, 9],
    ["n15", `Arkham is Elysium's launchpad.\n\nlaunch today, share it, get the crowd in. the fees follow the market cap\n\n#Elysium #CryptoCommunity #Memecoin #OnChain #ArkhamPad`, 11],
    ["n16", `nobody can pull the liquidity on an ArkhamPad coin. not you, not us. buyers trust that, and that's how coins grow\n\n#Elysium #LockedLiquidity #Memecoin #DeFi #Web3`, 14],
    ["n17", `3 steps. launch it. pass $25K. earn 50%. no code anywhere in there\n\n#Elysium #HowToLaunch #Crypto #Memecoins #ArkhamPad`, 12],
    ["n18", `you can launch a coin before your coffee gets cold. whether it's a joke or a real project, ArkhamPad pays the creator on every trade\n\n#Elysium #Memecoin #Crypto #Altcoins #HYPE`, 12],
    ["n19", `why launch on a pad that keeps the fees when you can launch on one that gives you up to 60%? ArkhamPad\n\n#Elysium #CryptoCreators #Memecoins #Launchpad #DeFi`, 10],
    ["n20", `a coin with 60% of fees going to its creator gets promoted harder. that's just how it works. launch yours on ArkhamPad\n\n#Elysium #Memecoin #CryptoMarketing #Web3 #Altcoins`, 10],
    ["n21", `Arkham is Elysium's launchpad.\n\nthe ladder: 20% at launch, 50% above $25K, 60% above $100K. which step are you on?\n\n#Elysium #Memecoin #CreatorFees #Crypto #HYPE`, 11],
    ["n22", `dev pays gas, coin goes live, trades start, fees land. ArkhamPad is the shortest path from idea to income on Elysium\n\n#Elysium #Hyperliquid #Memecoins #Web3 #TokenLaunch`, 15],
    ["n23", `people keep waiting for the next big Elysium coin. what if you launched it yourself and kept half the fees\n\n#Elysium #Memecoin #BuildInPublic #Crypto #Altcoin`, 9],
    ["n24", `if your coin holds $25K for an hour the fee split flips to you. that one hour is the whole game on ArkhamPad\n\n#Elysium #Memecoins #CryptoCreators #DeFi #HYPE`, 9],
    ["n25", `Arkham is Elysium's launchpad.\n\nlaunch fair, with locked liquidity, and still earn like a pro. creators get up to 60% of every trade fee\n\n#Elysium #FairLaunch #CryptoCreators #Memecoin #OnChain`, 14],
    ["n26", `small coin today, $100K coin tomorrow? the higher it goes the more of the fees you keep. ArkhamPad\n\n#Elysium #Memecoin #Altcoins #HYPE #Crypto`, 10],
    ["n27", `your community builds the market cap, the fees pay you. it's the simplest creator deal on Elysium right now 👀 ArkhamPad\n\n#Elysium #CryptoCommunity #Memecoins #Web3 #CreatorFees`, 15],
    ["n28", `one minute to launch. one hour above $25K. half the fees. read that again 👀 ArkhamPad\n\n#Elysium #Crypto #Memecoin #TokenLaunch #Hyperliquid`, 12],
    ["n29", `early Elysium creators are going to be the ones people remember. ArkhamPad is where you launch\n\n#Elysium #EarlyCrypto #Memecoins #Altcoins #HYPE`, 13],
    ["n30", `still thinking about launching? the 15% we hold for your first day is waiting. pass $25K and it's yours\n\n#Elysium #Memecoin #Crypto #CryptoCreators #ArkhamPad`, 16],
    ["n31", `Arkham is Elysium's launchpad.\n\nwake up, launch a coin, hold $25K for an hour, get paid half of every trade. repeat\n\n#Elysium #Memecoin #CryptoMorning #Web3 #HYPE`, 9],
    ["n32", `evening idea: launch the coin, post it, watch the crowd come. at $25K the fee split turns in your favor. ArkhamPad\n\n#Elysium #Memecoins #CryptoTwitter #Altcoins #DeFi`, 13],
  ];
}

// ------------------------------------------------------------------ Scout live signals (the wedge)
// Scout's STRONG smart-money catches, posted from @arkhampad, from ArkhamPad's OWN radar data
// (the shared Supabase the app reads). Nobody else shows "who's buying on Elysium" live. These fire
// at their own slots below; a slot only posts when there's a fresh strong catch (never floods), and
// the same coin is not reposted within 12h. Needs SCOUT_SUPABASE_URL + SCOUT_SUPABASE_KEY.
const SCOUT_PLAN = ["14:30", "16:00", "17:30", "19:00", "20:30", "22:00", "23:00"]; // ≤7/day
const SCOUT_ON = () => !!(process.env.SCOUT_SUPABASE_URL && process.env.SCOUT_SUPABASE_KEY);

async function sb(path) {
  const base = (process.env.SCOUT_SUPABASE_URL || "").replace(/\/$/, "");
  const key = process.env.SCOUT_SUPABASE_KEY;
  const r = await fetch(`${base}/rest/v1/${path}`, { headers: { apikey: key, authorization: `Bearer ${key}` }, signal: AbortSignal.timeout(12000) });
  if (!r.ok) throw new Error("sb " + r.status);
  return r.json();
}
async function getRadar() {
  const [tokens, trades, meta] = await Promise.all([sb(QUERIES.tokens), sb(QUERIES.trades), sb(QUERIES.meta)]);
  const usd = Number(meta && meta[0] && meta[0].v) || 0;
  return buildResponse(tokens, trades, usd, Date.now());
}
/** Short, pro, curiosity Scout-signal copy. {sym}=coin, {n}=smart wallets. Different line + tags each. */
function scoutLines(sym, n) {
  const S = `$${sym}`;
  return [
    ["sc1", `Scout just spotted smart money 👀\n\n${n} winning wallets aped ${S} on Elysium in the last 10 min. live now.\n\narkhampad.com\n\n#Elysium #SmartMoney`],
    ["sc2", `🚨 strong signal on Elysium\n\n${S} just lit up Scout's radar — ${n} smart wallets buying right now.\n\narkhampad.com\n\n#Elysium #OnChain #DeFi`],
    ["sc3", `while you were scrolling, ${n} smart wallets bought ${S} on Elysium 👀\n\nScout saw it first.\n\narkhampad.com\n\n#Elysium #Crypto`],
    ["sc4", `whales + smart money stacking ${S} on Elysium right now 🐋\n\nScout radar, live.\n\narkhampad.com\n\n#Elysium #Whales #SmartMoney`],
    ["sc5", `the money's moving on Elysium 👀\n\n${S} — ${n} smart wallets in, caught live by Scout.\n\narkhampad.com\n\n#Elysium #SmartMoney #Altcoins`],
    ["sc6", `${S} is lighting up Scout's radar on Elysium 👀\n\n${n} smart wallets just bought. you're early.\n\narkhampad.com\n\n#Elysium #OnChain #Crypto`],
    ["sc7", `smart money doesn't wait — ${n} winning wallets just bought ${S} on Elysium 🚨\n\nScout, live.\n\narkhampad.com\n\n#Elysium #DeFi #SmartMoney`],
    ["sc8", `Scout caught it: ${S} on Elysium, ${n} smart wallets buying in the last 10 min 👀\n\narkhampad.com\n\n#Elysium #Altcoins #SmartMoney`],
  ];
}

// ------------------------------------------------------------------ posting like a person
// The post itself carries no link (X shows link posts to fewer people); a reply right under it a little
// later carries arkhampad.com. Each line is reworded fresh by the AI (Cloudflare Workers AI: CF_ACCOUNT_ID +
// CF_AI_TOKEN on this service) so no two posts read alike; without the AI, or if its wording drops a key word
// or adds a number, the hand-written line goes out as it is.
const OPENER = "Arkham is Elysium's launchpad.";
const BRAND = "ArkhamPad, Elysium's launchpad: people create coins on Elysium in a minute and trade every Elysium coin there with HYPE or USDC, email login, safety checks on every coin";
const REPLIES = [
  `${LINK}`, `here 👉 ${LINK}`, `link: ${LINK}`, `try it → ${LINK}`, `${LINK} 👀`, `it's all on ${LINK}`,
  `trade it here: ${LINK}`, `👇\n${LINK}`, `start here → ${LINK}`, `${LINK} (email login, takes a minute)`,
];
function splitLine(text) {
  const lines = text.split("\n");
  const tags = lines.filter((l) => /^\s*#/.test(l)).join(" ").trim();
  let body = lines.filter((l) => !/^\s*#/.test(l) && !l.includes(LINK)).join("\n").replace(/\n{3,}/g, "\n\n").trim();
  let opener = "";
  if (body.startsWith(OPENER)) { opener = OPENER; body = body.slice(OPENER.length).trim(); }
  return { opener, body, tags };
}
async function compose(pool, text) {
  const { opener, body, tags } = splitLine(text);
  const must = [...new Set([...(body.match(/\$[A-Za-z0-9]+|@\w+/g) || []), ...(/ArkhamPad/i.test(body) ? ["ArkhamPad"] : [])])];
  const recent = (await pool.query(`select text from arkx_posts where text is not null order by posted_at desc limit 8`).catch(() => ({ rows: [] }))).rows.map((r) => r.text);
  const room = 270 - opener.length - tags.length - 4;
  const out = await writePost({ facts: body, fallback: body, must, recent, max: room, brand: BRAND }).catch(() => body);
  return [opener, out, tags].filter(Boolean).join("\n\n");
}
/**
 * The post (no link). Nov 5: the link reply under FOMO and Scout posts is off by default to cut cost (X charges
 * far more for a post with a link; 21+ a day added up). ARK_X_LINK_REPLIES=1 turns it back on. Returns the id.
 */
async function publish(keys, text) {
  const id = await postTweet(keys, text);
  if (id && process.env.ARK_X_LINK_REPLIES === "1") {
    await sleep(20_000 + Math.floor(Math.random() * 50_000));
    await postTweet(keys, REPLIES[Math.floor(Math.random() * REPLIES.length)], id).catch((e) => log("link reply: " + String(e.message).slice(0, 160)));
  }
  return id;
}

// ------------------------------------------------------------------ the day's plan (Türkiye time)
// The corporate / FOMO posts. Set ARK_X_FOMO_OFF=1 to post ONLY Scout signals.
const PLAN = [
  // morning: ~every 45 min, 06:00–12:45
  "06:00", "06:45", "07:30", "08:15", "09:00", "09:45", "10:30", "11:15", "12:00", "12:45",
  // evening: ~every 45 min, 15:15–22:40
  "15:15", "16:00", "16:45", "17:30", "18:15", "19:00", "19:45", "20:30", "21:15", "22:00", "22:40",
];

/** Today's time (ms) for a slot, moved by a fixed ±12 min for that day + slot. */
function slotTime(at, now = Date.now()) {
  const day = new Date(now + TR).toISOString().slice(0, 10);
  let h = 2166136261;
  for (const ch of `${day}:${at}`) h = Math.imul(h ^ ch.charCodeAt(0), 16777619) >>> 0;
  const jitter = (h % 25) - 12; // minutes
  const [hh, mm] = at.split(":").map(Number);
  return Date.parse(`${day}T00:00:00Z`) - TR + ((hh * 60 + mm + jitter) * 60e3);
}

/** One line not posted in the last 10 days (else any). */
async function fresh(pool, list) {
  const { rows } = await pool
    .query(`select tpl from arkx_posts where posted_at > now() - interval '10 days'`)
    .catch(() => ({ rows: [] }));
  const used = new Set(rows.map((r) => r.tpl));
  const left = list.filter(([id]) => !used.has(id));
  return (left.length ? left : list)[Math.floor(Math.random() * (left.length || list.length))];
}

async function main() {
  if (process.env.ARK_X_OFF === "1") return log("off (ARK_X_OFF=1)");
  const keys = {
    apiKey: process.env.ARK_X_API_KEY,
    apiSecret: process.env.ARK_X_API_SECRET,
    accessToken: process.env.ARK_X_ACCESS_TOKEN,
    accessSecret: process.env.ARK_X_ACCESS_SECRET,
  };
  if (!keys.apiKey || !keys.apiSecret || !keys.accessToken || !keys.accessSecret) return log("no X keys set — nothing to do");
  const dry = process.env.ARK_X_DRY === "1";

  const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL, max: 2 });
  await pool.query(`create table if not exists arkx_posts (id bigserial primary key, slot text, tpl text, post_id text, posted_at timestamptz default now())`);
  await pool.query(`alter table arkx_posts add column if not exists coin text`).catch(() => {});
  await pool.query(`alter table arkx_posts add column if not exists text text`).catch(() => {});
  const fomoOff = process.env.ARK_X_FOMO_OFF === "1";
  log(`on${dry ? " (dry run)" : ""}; ${CREATOR_ON() ? `${CREATOR_PLAN.length} creator posts/day with images + ` : ""}${fomoOff ? 0 : PLAN.length} FOMO posts/day + ${SCOUT_ON() ? `up to ${SCOUT_PLAN.length} Scout signals/day` : "Scout off (no Supabase)"}`);

  // a tiny health endpoint so Railway sees the service as up
  if (process.env.PORT) {
    const http = await import("node:http");
    http.createServer((_, res) => res.end("ok")).listen(Number(process.env.PORT));
  }

  for (;;) {
    try {
      const now = Date.now();
      const today = new Date(now + TR).toISOString().slice(0, 10);

      // Never two posts within ~25 min (keeps FOMO + Scout from clustering when their slots overlap).
      const recent = await pool.query(`select 1 from arkx_posts where post_id <> 'dry' and posted_at > now() - interval '25 minutes' limit 1`).catch(() => ({ rows: [] }));
      // and not within 10 min of an ElyScreener post (same database), so the two accounts never post together
      const es = await pool.query(`select 1 from es_x_posts where tweet_id is not null and at > now() - interval '10 minutes' limit 1`).catch(() => ({ rows: [] }));
      const quiet = (recent.rows.length === 0 && es.rows.length === 0) || dry;

      let posted = false;
      // 0) The creator campaign first, at its own slots: a post with its image (and the link as a reply if
      //    ARK_X_CREATOR_LINK=1).
      if (quiet && CREATOR_ON()) {
        for (const at of CREATOR_PLAN) {
          const t = slotTime(at, now);
          if (now < t || now > t + 2 * 3600e3) continue; // due, and no more than 2h late
          const cslot = `creator:${at}`;
          const done = await pool.query(`select 1 from arkx_posts where slot = $1 and posted_at::date = $2 limit 1`, [cslot, today]).catch(() => ({ rows: [] }));
          if (done.rows.length) continue;
          const [tpl, line, img] = await fresh(pool, CREATOR());
          const text = await compose(pool, line);
          if (dry) {
            log(`[dry] ${cslot} ${tpl} (image ${img})\n${text}`);
            await pool.query(`insert into arkx_posts (slot, tpl, post_id, text) values ($1,$2,$3,$4)`, [cslot, tpl, "dry", text]);
          } else {
            const mediaId = await uploadImage(keys, card(img));
            const id = await postTweetWithImage(keys, text, mediaId);
            await pool.query(`insert into arkx_posts (slot, tpl, post_id, text) values ($1,$2,$3,$4)`, [cslot, tpl, id ?? "", text]);
            log(`posted ${cslot} ${tpl} (image ${img}) -> ${id}`);
            if (id && process.env.ARK_X_CREATOR_LINK !== "0") {
              await sleep(20_000 + Math.floor(Math.random() * 50_000));
              await postTweet(keys, REPLIES[Math.floor(Math.random() * REPLIES.length)], id).catch((e) => log("link reply: " + String(e.message).slice(0, 160)));
            }
          }
          posted = true;
          break;
        }
      }

      // 1) Scout live signals take priority at their slots (strong catches only; never floods).
      if (quiet && !posted && SCOUT_ON()) {
        for (const at of SCOUT_PLAN) {
          const t = slotTime(at, now);
          if (now < t || now > t + 60 * 60e3) continue; // due, and no more than 1h late
          const sslot = `scout:${at}`;
          const done = await pool.query(`select 1 from arkx_posts where slot = $1 and posted_at::date = $2 limit 1`, [sslot, today]).catch(() => ({ rows: [] }));
          if (done.rows.length) continue;
          const radar = await getRadar().catch((e) => (log("radar: " + String(e.message).slice(0, 120)), null));
          if (!radar || !radar.coins) break;
          const blk = await pool.query(`select coin from arkx_posts where coin is not null and posted_at > now() - interval '12 hours'`).catch(() => ({ rows: [] }));
          const blocked = new Set(blk.rows.map((r) => String(r.coin).toLowerCase()));
          const pick = radar.coins.find((c) => c.signal === "strong" && !blocked.has(String(c.address).toLowerCase()));
          if (!pick) { log(`${sslot}: no fresh strong catch — skipping`); break; }
          const n = pick.smartCount || pick.notableCount || pick.recentCount || 2;
          const [tpl, line] = await fresh(pool, scoutLines(pick.symbol, n));
          const text = await compose(pool, line);
          if (dry) {
            log(`[dry] ${sslot} ${tpl} (${pick.symbol})\n${text}`);
            await pool.query(`insert into arkx_posts (slot, tpl, coin, post_id, text) values ($1,$2,$3,$4,$5)`, [sslot, tpl, pick.address, "dry", text]);
          } else {
            const id = await publish(keys, text);
            await pool.query(`insert into arkx_posts (slot, tpl, coin, post_id, text) values ($1,$2,$3,$4,$5)`, [sslot, tpl, pick.address, id ?? "", text]);
            log(`posted ${sslot} ${tpl} ${pick.symbol} -> ${id}`);
          }
          posted = true;
          break;
        }
      }

      // 2) Corporate / FOMO posts fill the other slots (unless turned off).
      if (quiet && !posted && !fomoOff) {
        for (const at of PLAN) {
          const t = slotTime(at, now);
          if (now < t || now > t + 3 * 3600e3) continue; // its time has come, and no more than 3h late
          const done = await pool.query(`select 1 from arkx_posts where slot = $1 and posted_at::date = $2 limit 1`, [at, today]).catch(() => ({ rows: [] }));
          if (done.rows.length) continue;
          const [tpl, line] = await fresh(pool, POSTS());
          const text = await compose(pool, line);
          if (dry) {
            log(`[dry] ${at} ${tpl}\n${text}`);
            await pool.query(`insert into arkx_posts (slot, tpl, post_id, text) values ($1,$2,$3,$4)`, [at, tpl, "dry", text]);
          } else {
            const id = await publish(keys, text);
            await pool.query(`insert into arkx_posts (slot, tpl, post_id, text) values ($1,$2,$3,$4)`, [at, tpl, id ?? "", text]);
            log(`posted ${at} ${tpl} -> ${id}`);
          }
          break; // one post per pass
        }
      }
    } catch (e) {
      log(String(e.message).slice(0, 300));
      if (/ 4\d\d:/.test(String(e.message))) await sleep(20 * 60e3); // X refused (keys/credits): back off
    }
    await sleep(60e3);
  }
}

main().catch((e) => { log("fatal:", e.message); process.exit(1); });
