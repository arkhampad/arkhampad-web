"use client";
import { formatUnits } from "viem";
// Token page (/t/?a=0x…): any Elysium token, from any launchpad. Chart, buy/sell, trades, holders.
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useEffect, useMemo, useRef, useState } from "react";
import type { Address } from "viem";
import { useWallet } from "@/components/wallet";
import { funnel } from "@/lib/funnel";
import { RingAvatar, TokenAvatar } from "./shell";
import { useT } from "@/lib/i18n";
import { EChart } from "./chart";
import { ScoutPanel } from "./scout";
import { ShieldPanel } from "./shield";
import { useShield, useDevRecord } from "@/lib/shield";
import { Burst, Confetti } from "@/components/celebrate";
import { ShareButton } from "./share";
import { telegramText, useCoinLinks, type CoinLinks } from "@/lib/sharecard";
import { chainActivity, isFresh, mergeTrades } from "@/lib/elyfresh";
import { pendingTrade } from "@/lib/holdings";
import { ago, compact, fetchClusters, fetchHolders, fetchHypeUsd, fetchToken, fetchTrades, money, pct, short, tinyPrice, usePoll, type EHolder, type EToken, type ETrade } from "@/lib/ely";
import { ascendBuy, ascendQuote, ascendSell, isAscend, quoteToken, type QuoteToken } from "@/lib/ascend";
import { ELY_EXPLORER, ROUTER, buy, canTrade, fromWei, hypeBalance, cachedHype, quote, sell, toWei, tokenBalance, TradeFail, chainToken, pendingToken, SlowTx, taxedTokens, sellable } from "@/lib/elytrade";

const GAS_KEEP = 2_000_000_000_000_000n; // 0.002 HYPE stays for gas on "Max"
const supplyOf = (t: EToken) => Number(BigInt(t.supply || "0")) / 10 ** (t.decimals ?? 18);
const upDown = (v: number | null | undefined) => ((v ?? 0) >= 0 ? "up" : "down");
const amt = (n: number) => (n >= 1e9 ? `${(n / 1e9).toFixed(2)}B` : n >= 1e6 ? `${(n / 1e6).toFixed(2)}M` : n >= 1e3 ? `${(n / 1e3).toFixed(1)}K` : n.toLocaleString("en-US", { maximumFractionDigits: n < 1 ? 6 : 2 }));

/** A short address you can tap to copy in full; shows "Copied" for a moment. */
function CopyAddr({ a }: { a: string }) {
  const [ok, setOk] = useState(false);
  return (
    <button type="button" className="e-addrcopy num" title={a} aria-label={`Copy ${a}`}
      onClick={(e) => { e.preventDefault(); e.stopPropagation(); navigator.clipboard?.writeText(a).then(() => { setOk(true); setTimeout(() => setOk(false), 1400); }).catch(() => {}); }}>
      {ok ? "Copied" : short(a)}
    </button>
  );
}

function Copy({ text, label }: { text: string; label?: string }) {
  const [ok, setOk] = useState(false);
  return (
    <button type="button" className="e-copy" onClick={() => { navigator.clipboard?.writeText(text).then(() => { setOk(true); setTimeout(() => setOk(false), 1400); }).catch(() => {}); }} aria-label={`Copy ${label ?? text}`}>
      <span className="num">{label ?? short(text)}</span>
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">{ok ? <path d="m5 12 5 5 9-10" /> : <><rect x="9" y="9" width="11" height="11" rx="2" /><path d="M5 15V5a2 2 0 0 1 2-2h8" /></>}</svg>
    </button>
  );
}

function TradeBox({ t, usd, side: side0 = "buy", onDone, compact: cmp, preset }: { t: EToken; usd: number; side?: "buy" | "sell"; onDone?: () => void; compact?: boolean; preset?: string }) {
  const tr = useT();
  const w = useWallet();
  const [side, setSide] = useState<"buy" | "sell">(side0);
  const [val, setVal] = useState(preset && side0 === "buy" ? preset : "");
  const [slip, setSlip] = useState(5);
  const [out, setOut] = useState<bigint | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [tick, setTick] = useState(0);
  useEffect(() => setSide(side0), [side0]);
  const dec = t.decimals ?? 18;
  const addr = w.address as Address | null;
  // what this coin is bought with: HYPE for most pools; USDC on Ascend's pools
  const asc = isAscend(t);
  const HYPE_Q: QuoteToken = { address: "0x0000000000000000000000000000000000000000", symbol: "HYPE", decimals: 18, native: true, usd: false };
  const qt = usePoll(async () => (asc ? quoteToken(t) : HYPE_Q), 600_000, [t.address, asc]) ?? HYPE_Q;
  const qDec = qt.decimals;
  const qSym = qt.symbol;
  const qNative = qt.native;
  const hypeRead = usePoll(async () => (addr ? (qNative ? hypeBalance(addr) : tokenBalance(qt.address, addr)) : null), 6000, [addr, tick, qt.address]) ?? (qNative ? cachedHype(addr) : undefined);
  const balRead = usePoll(async () => (addr ? tokenBalance(t.address as Address, addr) : null), 6000, [addr, t.address, tick]);
  // right after a trade the nodes still show the old balances for a while: show the expected ones until then
  const [after, setAfter] = useState<{ hype: bigint; bal: bigint; until: number } | null>(null);
  const live = after && Date.now() < after.until;
  const hype = live ? after.hype : hypeRead;
  const bal = live ? after.bal : balRead;
  // a % / Max button sets the exact on-chain amount (typing a number clears it), so 100% never ends up a
  // hair above the real balance because of rounding
  const [exact, setExact] = useState<bigint | null>(null);
  const inWei = exact ?? toWei(val, side === "buy" ? qDec : dec);
  const tradable = canTrade(t) || asc;
  const getQuote = (isBuy: boolean, amount: bigint) => (asc ? ascendQuote(t, isBuy, amount, addr) : quote(t, isBuy, amount, addr));

  // other launchpads' coins: make sure a buyer can sell back here before letting them buy (taxed coins)
  const unsellable = usePoll(async () => (!asc && !t.ours && canTrade(t) ? (await sellable(t)) === false : false), 600_000, [t.address, asc]) ?? false;
  const [noRoute, setNoRoute] = useState(false);
  useEffect(() => {
    setOut(null);
    if (!tradable || inWei <= 0n) return;
    let on = true;
    const id = setTimeout(async () => {
      const q = await getQuote(side === "buy", inWei).catch(() => null);
      if (!on) return;
      setOut(q);
      setNoRoute(q === null);
    }, 250);
    return () => { on = false; clearTimeout(id); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [inWei, side, t, tradable, addr, asc]);

  // price in what the coin is bought with (HYPE, or USD on a USDC pool)
  const price = (t.price_hype ?? 0) * (qt.usd ? usd : 1);
  const estOut = out !== null ? fromWei(out, side === "buy" ? dec : qDec) : price > 0 && inWei > 0n ? (side === "buy" ? fromWei(inWei, qDec) / price : fromWei(inWei, dec) * price) : 0;
  const perQ = qt.usd ? 1 : usd;
  const inUsd = side === "buy" ? fromWei(inWei, qDec) * perQ : fromWei(inWei, dec) * price * perQ;
  const sym = t.symbol;
  const short1 = side === "buy" ? hype != null && inWei > hype : bal != null && inWei > bal;

  const keep = qNative ? GAS_KEEP : 0n; // HYPE keeps a little for gas; USDC can all go
  const quick = side === "buy"
    ? [...(qt.usd ? ["5", "10", "50"] : ["0.1", "0.5", "1"]).map((v) => ({ l: v, v, x: null as bigint | null })), (() => { const x = hype != null && hype > keep ? hype - keep : 0n; return { l: tr("Max"), v: hype != null ? trim(formatUnits(x, qDec)) : "", x: hype != null ? x : null }; })()]
    : [25, 50, 75, 100].map((p) => { const x = bal != null ? (bal * BigInt(p)) / 100n : null; return { l: `${p}%`, v: x != null ? trim(formatUnits(x, dec)) : "", x }; });

  // one trade at a time: the button is locked from the first tap until the network has taken the trade
  // (a second or two); then the result shows at once and the chain's confirmation follows in the background
  const going = useRef(false);
  async function go() {
    if (!w.signedIn || !w.signer) return w.login();
    if (going.current) return;
    going.current = true;
    (document.activeElement as HTMLElement | null)?.blur?.(); // close the phone keyboard
    setMsg(null);
    setBusy(tr(side === "buy" ? "Buying…" : "Selling…"));
    try {
      const q = out ?? (await getQuote(side === "buy", inWei));
      if (q === null) throw new TradeFail("This token can't be traded here right now.");
      const min = (q * BigInt(100 - slip)) / 100n;
      const amountIn = inWei;
      const step = (x: string) => setBusy(tr(x));
      const sent = asc
        ? side === "buy" ? await ascendBuy(w.signer, t, amountIn, min, step) : await ascendSell(w.signer, t, amountIn, min, step)
        : side === "buy" ? await buy(w.signer, t, amountIn, min) : await sell(w.signer, t, amountIn, min, step);
      const done = side === "buy" ? tr("Bought {n} {sym}", { n: amt(fromWei(q, dec)), sym }) : qNative ? tr("Sold for {n} HYPE", { n: fromWei(q).toFixed(4) }) : `${tr("Sold for")} ${fromWei(q, qDec).toFixed(qt.usd ? 2 : 4)} ${qSym}`;
      // the network has it: show the result and the new balances now
      const h0 = hype ?? 0n;
      const b0 = bal ?? 0n;
      const nextHype = side === "buy" ? (h0 > amountIn ? h0 - amountIn : 0n) : h0 + q;
      const nextBal = side === "buy" ? b0 + q : b0 > amountIn ? b0 - amountIn : 0n;
      setAfter({ hype: nextHype, bal: nextBal, until: Date.now() + 90_000 });
      // the header and You move HYPE and the coin together (no jump while the trade is on its way)
      if (addr) pendingTrade(addr, t, { hypeFrom: qNative ? h0 : null, hypeTo: qNative ? nextHype : null, tokFrom: b0, tokTo: nextBal });
      setMsg({ ok: true, text: `${done} ✓` });
      setVal("");
      setExact(null);
      setBusy(null);
      going.current = false;
      sent.confirmed.then(
        () => { funnel(addr, "trade"); setAfter(null); setTick((x) => x + 1); onDone?.(); },
        (e) => {
          // not confirmed after two minutes: don't leave "Sold"/"Bought" on screen as if it happened
          if (e instanceof SlowTx) { setAfter(null); setTick((x) => x + 1); setMsg({ ok: false, text: tr("Not confirmed yet. Check your balance in a minute before trying again.") }); return; }
          setAfter(null);
          setTick((x) => x + 1);
          setMsg({ ok: false, text: tr(e instanceof TradeFail ? e.message : "Trade failed. Please try again.") });
        },
      );
    } catch (e) {
      setMsg({ ok: false, text: tr(e instanceof TradeFail ? e.message : "Trade failed. Please try again.") });
    } finally {
      setBusy(null);
      going.current = false;
    }
  }

  let label = tr(side === "buy" ? "Buy {sym}" : "Sell {sym}", { sym });
  let disabled = !!busy;
  if (!w.signedIn) label = tr("Log in to trade");
  else if (!ROUTER && !asc) { label = tr("Trading opens soon"); disabled = true; }
  else if (!tradable || (noRoute && inWei > 0n)) { label = tr("Not tradable here yet"); disabled = true; }
  else if (side === "buy" && unsellable) { label = tr("Can't be sold here"); disabled = true; }
  else if (inWei <= 0n) { label = tr("Enter an amount"); disabled = true; }
  else if (short1) { label = side === "buy" ? (qNative ? tr("Not enough HYPE") : `${tr("Not enough")} ${qSym}`) : tr("Not enough {sym}", { sym }); disabled = true; }
  if (busy) label = busy;

  return (
    <div className="e-trade">
      <div className="e-bs">
        <button type="button" className={side === "buy" ? "on buy" : ""} onClick={() => { setSide("buy"); setVal(""); setExact(null); }}>{tr("Buy")}</button>
        <button type="button" className={side === "sell" ? "on sell" : ""} onClick={() => { setSide("sell"); setVal(""); setExact(null); }}>{tr("Sell")}</button>
      </div>
      <label className="e-amt">
        <span className="e-amt-top"><span>{tr(side === "buy" ? "You pay" : "You sell")}</span><span className="dim">{tr("Balance")} {side === "buy" ? (hype != null ? `${fromWei(hype, qDec).toFixed(qt.usd ? 2 : 4)} ${qSym}` : "—") : bal != null ? `${amt(fromWei(bal, dec))} ${sym}` : "—"}</span></span>
        <span className="e-amt-row">
          <input inputMode="decimal" placeholder="0" value={val} onChange={(e) => { setExact(null); setVal(e.target.value.replace(/[^0-9.,]/g, "")); }} aria-label="Amount" autoComplete="off" />
          <b>{side === "buy" ? qSym : sym}</b>
        </span>
        <span className="dim num" style={{ fontSize: 12.5 }}>≈ {money(inUsd)}</span>
      </label>
      <div className="e-quick">{quick.map((q) => <button key={q.l} type="button" onMouseDown={(e) => e.preventDefault()} onClick={() => { if (!q.v) return; setVal(q.v); setExact(q.x); }} disabled={!q.v}>{q.l}</button>)}</div>
      <div className="e-recv">
        <span className="muted">{tr("You get")}</span>
        <b className="num">{estOut > 0 ? `≈ ${amt(estOut)} ${side === "buy" ? sym : qSym}` : "—"}</b>
      </div>
      {taxedTokens.has(t.address.toLowerCase()) && <div className="e-hint" style={{ marginBottom: 8 }}>{tr("This coin takes a tax on every trade. The amount shown is what you get after it.")}</div>}
      <div className="e-slip">
        <span className="dim">{tr("Slippage")}</span>
        {cmp ? <select value={slip} onChange={(e) => setSlip(Number(e.target.value))} aria-label={tr("Slippage")}>{[1, 3, 5, 10].map((s) => <option key={s} value={s}>{s}%</option>)}</select>
          : <div className="e-seg">{[1, 3, 5, 10].map((s) => <button key={s} type="button" className={slip === s ? "on" : ""} onMouseDown={(e) => e.preventDefault()} onClick={() => setSlip(s)}>{s}%</button>)}</div>}
      </div>
      <button type="button" className={`e-go ${side}`} disabled={disabled && w.signedIn} onMouseDown={(e) => e.preventDefault()} onClick={go}>{label}</button>
      {msg && <div className={`e-msg ${msg.ok ? "ok" : "bad"}`} role="status">{msg.text}</div>}
      {side === "buy" && unsellable && <div className="e-msg bad" role="status">{tr("This coin takes a tax on trades and may not be sellable here. Trade it on its own site.")}</div>}
      {asc && !qNative && <div className="e-hint" style={{ marginTop: 8 }}>{tr("This coin trades in {q}. You pay and receive {q} on Elysium; gas is paid in HYPE.", { q: qSym })}</div>}
      {w.signedIn && hype === 0n && side === "buy" && qNative && <Link href="/bridge/" className="e-hint">{tr("No HYPE on Elysium yet.")} <b>{tr("Add HYPE or USDC →")}</b></Link>}
    </div>
  );
}

/** Shows an exact amount without a long tail: at most 6 decimals, trailing zeros dropped (rounded down). */
const trim = (v: string) => { const [a, b = ""] = v.split("."); const d = b.slice(0, 6).replace(/0+$/, ""); return d ? `${a}.${d}` : a; };

function MiniTrades({ t, usd, chain }: { t: EToken; usd: number; chain?: ETrade[] | null }) {
  const tr = useT();
  const db = usePoll(() => fetchTrades(t.address, 40), 6000, [t.address]);
  const trades = useMemo(() => mergeTrades(db, chain)?.slice(0, 40) ?? (chain ? chain.slice(0, 40) : undefined), [db, chain]);
  const last = trades ?? [];
  const buys = last.length ? Math.round((last.filter((x) => x.side === "buy").length / last.length) * 100) : 50;
  return (
    <div className="e-mini">
      <div className="e-mini-h"><span>{tr("Live trades")}</span><span>HYPE</span></div>
      {!trades && <div className="e-skel" style={{ height: 120 }} />}
      {trades && !trades.length && <div className="dim" style={{ padding: "18px 0", textAlign: "center", fontSize: 12.5 }}>{tr("No trades yet.")}</div>}
      {last.slice(0, 12).map((x) => (
        <div key={`${x.tx}-${x.log_index}`} className="e-mini-r">
          <b className={x.side === "buy" ? "up" : "down"}>{x.side === "buy" ? "BUY" : "SELL"}</b>
          <span className="dim num">{x.trader ? short(x.trader) : "—"}</span>
          <i className="num">{x.hype.toFixed(x.hype < 1 ? 3 : 2)}</i>
        </div>
      ))}
      {!!last.length && <div className="e-mini-bar"><div><i style={{ width: `${buys}%` }} /></div><div className="e-mini-bl"><span className="up">{tr("buys")} {buys}%</span><span className="down">{100 - buys}% {tr("sells")}</span></div></div>}
    </div>
  );
}
function Trades({ t, usd, chain }: { t: EToken; usd: number; chain?: ETrade[] | null }) {
  const tr = useT();
  const db = usePoll(() => fetchTrades(t.address, 60), 6000, [t.address]);
  const trades = useMemo(() => mergeTrades(db, chain)?.slice(0, 60) ?? (chain ? chain.slice(0, 60) : undefined), [db, chain]);
  if (!trades) return <div style={{ padding: 14, display: "grid", gap: 8 }}>{Array.from({ length: 6 }, (_, i) => <div key={i} className="e-skel" style={{ height: 40 }} />)}</div>;
  if (!trades.length) return <div className="e-empty">{tr("No trades yet.")}</div>;
  return (
    <div className="e-rows">
      <div className="e-row e-tr h"><span>{tr("Time")}</span><span>{tr("Type")}</span><span className="r">USD</span><span className="r e-hide-m">HYPE</span><span className="r">{t.symbol}</span><span className="r e-hide-m">{tr("Trader")}</span></div>
      {trades.map((x) => {
        const href = ELY_EXPLORER ? `${ELY_EXPLORER}/tx/${x.tx}` : undefined;
        const Cell = href ? "a" : "div";
        return (
          <Cell key={`${x.tx}-${x.log_index}`} className="e-row e-tr" {...(href ? { href, target: "_blank", rel: "noopener noreferrer" } : {})}>
            <span className="dim">{ago(x.at)}</span>
            <span className={x.side === "buy" ? "up" : "down"} style={{ fontWeight: 700 }}>{tr(x.side === "buy" ? "Buy" : "Sell")}</span>
            <span className={`r num ${x.side === "buy" ? "up" : "down"}`}>{money(x.hype * usd)}</span>
            <span className="r num e-hide-m">{x.hype.toFixed(x.hype < 1 ? 4 : 2)}</span>
            <span className="r num">{amt(x.amount)}</span>
            <span className="r num dim e-hide-m">{x.trader ? <CopyAddr a={x.trader} /> : "—"}</span>
          </Cell>
        );
      })}
    </div>
  );
}

function Holders({ t, chain }: { t: EToken; chain?: EHolder[] | null }) {
  const tr = useT();
  const db = usePoll(() => fetchHolders(t.address, 30), 20000, [t.address]);
  const cl = usePoll(() => fetchClusters(t.address), 30000, [t.address]);
  // the index's list, or (a young coin it hasn't caught up with) the balances read from the chain
  const rows = db && db.length ? db : chain?.length ? chain.slice(0, 30) : db;
  const sup = supplyOf(t) || 1;
  if (!rows) return <div style={{ padding: 14, display: "grid", gap: 8 }}>{Array.from({ length: 6 }, (_, i) => <div key={i} className="e-skel" style={{ height: 36 }} />)}</div>;
  if (!rows.length) return <div className="e-empty">{tr("Holder list is loading. Check back in a minute.")}</div>;
  const isPool = (h: string) => h === (t.pool || "").toLowerCase() || h === (t.manager || "").toLowerCase();
  const danger = !!cl && cl.cluster_supply_pct >= 20;
  return (
    <div className="e-rows">
      {cl && cl.clusters > 0 && (
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10, padding: "10px 12px", marginBottom: 6, borderRadius: 10, background: danger ? "rgba(246,70,93,0.10)" : "rgba(128,128,128,0.08)", border: `1px solid ${danger ? "rgba(246,70,93,0.35)" : "transparent"}` }}>
          <span style={{ display: "flex", flexDirection: "column", minWidth: 0 }}>
            <b style={{ fontSize: 15, color: danger ? "var(--down, #F6465D)" : undefined }}>{cl.cluster_supply_pct.toFixed(0)}% {tr("in bot clusters")}</b>
            <span className="dim" style={{ fontSize: 11 }}>{cl.clusters} {tr("bundles")} · {cl.cluster_wallets} {tr("wallets")} · {tr("biggest")} {cl.biggest_cluster_pct.toFixed(0)}%</span>
          </span>
          <span className="dim" style={{ fontSize: 10, textAlign: "right", maxWidth: 140, lineHeight: 1.3 }}>{tr("Wallets that bought in the same block")}</span>
        </div>
      )}
      {rows.map((h, i) => {
        const p = (Number(h.amount) / 10 ** (t.decimals ?? 18) / sup) * 100;
        return (
          <div key={h.holder} className="e-row e-hr">
            <span className="dim num">{i + 1}</span>
            <span className="num"><CopyAddr a={h.holder} /> {isPool(h.holder) && <span className="e-lock">{tr("Pool")}</span>}{h.holder === (t.creator || "").toLowerCase() && <span className="e-lock">{tr("Creator")}</span>}</span>
            <span className="e-hbar"><i style={{ width: `${Math.min(100, p)}%` }} /></span>
            <span className="r num">{p.toFixed(2)}%</span>
          </div>
        );
      })}
    </div>
  );
}

function About({ t, links }: { t: EToken; links: CoinLinks }) {
  const tr = useT();
  const desc = t.description || links.description;
  return (
    <div className="e-about">
      {desc && <p>{desc}</p>}
      {(links.x || links.telegram || links.website) && (
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", padding: "0 0 12px" }}>
          {links.x && <a className="e-btn" href={links.x} target="_blank" rel="noopener noreferrer nofollow">X {links.xHandle ?? ""}</a>}
          {links.telegram && <a className="e-btn" href={links.telegram} target="_blank" rel="noopener noreferrer nofollow">Telegram</a>}
          {links.website && <a className="e-btn" href={links.website} target="_blank" rel="noopener noreferrer nofollow">{tr("Website")}</a>}
        </div>
      )}
      <dl>
        <div><dt>{tr("Contract")}</dt><dd><Copy text={t.address} /></dd></div>
        <div><dt>{tr("Creator")}</dt><dd>{t.creator ? <Copy text={t.creator} /> : "—"}</dd></div>
        <div><dt>{tr("Pool")}</dt><dd>{t.venue === "cl" ? "PancakeSwap Infinity" : t.venue === "v4" ? "Uniswap v4" : "Uniswap v3"} · {tr("{n}% fee", { n: (t.fee ?? 0) / 10000 })}</dd></div>
        <div><dt>{tr("Supply")}</dt><dd className="num">{compact(supplyOf(t))}</dd></div>
        <div><dt>{tr("Created")}</dt><dd>{t.created_at ? `${new Date(t.created_at).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })} · ${tr("{age} ago", { age: ago(t.created_at) })}` : "—"}</dd></div>
      </dl>
    </div>
  );
}

export function TokenPage() {
  const tr = useT();
  const router = useRouter();
  const params = useSearchParams();
  const a = (params.get("a") || "").toLowerCase();
  const valid = /^0x[0-9a-f]{40}$/.test(a);
  // "Buy 0.1" from Discover: the amount is filled in and the page scrolls to the buy box
  const [sheet, setSheet] = useState<"buy" | "sell" | null>(null);
  const buyPreset = /^\d+(\.\d+)?$/.test(params.get("buy") || "") ? (params.get("buy") as string) : undefined;
  useEffect(() => { if (!buyPreset) return; const id = setTimeout(() => { if (window.innerWidth <= 860) setSheet("buy"); else document.getElementById("trade-side")?.scrollIntoView({ behavior: "smooth", block: "center" }); }, 500); return () => clearTimeout(id); }, [buyPreset, a]);
  // a coin launched a moment ago may not be indexed yet: read it from the chain until it is
  // a coin launched here a moment ago: the launch's own record fills in until a node / the indexer has it
  const pend = valid ? pendingToken(a) : null;
  const t0 = usePoll(async () => (valid ? ((await fetchToken(a).catch(() => null)) ?? (await chainToken(a)) ?? pendingToken(a)) : null), pend ? 5000 : 15_000, [a]) ?? pend ?? undefined;
  const usd = usePoll(fetchHypeUsd, 30_000) ?? 0;
  const dbTrades = usePoll(async () => (valid ? fetchTrades(a, 1500) : []), 15_000, [a]);
  // a young coin: trades and holders straight from the chain every few seconds (the index lags a minute or two)
  const young = !!t0 && isFresh(t0);
  const live = usePoll(async () => (t0 && young ? chainActivity(t0).catch(() => null) : null), 4000, [t0?.address, young]);
  // a young coin's price and market cap follow its latest trade on chain (the index catches up later)
  const t = useMemo(() => {
    const last = live?.trades[0];
    if (!t0 || !last?.price_hype) return t0;
    if (t0.last_trade_at && Date.parse(t0.last_trade_at) >= Date.parse(last.at)) return t0;
    return { ...t0, price_hype: last.price_hype, mcap_hype: last.price_hype * supplyOf(t0) };
  }, [t0, live]);
  const trades = useMemo(() => mergeTrades(dbTrades, live?.trades) ?? (live ? live.trades : undefined), [dbTrades, live]);
  const [tab, setTab] = useState<"trades" | "holders" | "about">("trades");
  const [fresh, setFresh] = useState(params.get("new") === "1");
  const links = useCoinLinks(t ?? null);
  const shield = useShield(t ?? null, trades, usd);
  const dev = useDevRecord(t?.creator, usd);

  useEffect(() => { if (t) document.title = `${t.symbol} · ${money((t.mcap_hype ?? 0) * usd)} · ArkhamPad`; }, [t, usd]);
  useEffect(() => {
    if (!sheet) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = prev; };
  }, [sheet]);

  const liveVol = useMemo(() => (live?.trades ?? []).filter((x) => Date.now() - Date.parse(x.at) < 86_400_000).reduce((n, x) => n + x.hype, 0), [live]);
  const stats = useMemo(() => {
    if (!t) return [];
    return [
            { l: tr("Price"), v: tinyPrice((t.price_hype ?? 0) * usd) },
      { l: tr("24h volume"), v: money(Math.max(t.vol24_hype || 0, liveVol) * usd) },
      { l: tr("Holders"), v: compact(Math.max(t.holders || 0, live?.holders.length ?? 0)) },
      { l: tr("Top 10"), v: t.top10_pct == null ? "—" : `${Math.min(100, t.top10_pct).toFixed(0)}%` },
      { l: tr("24h txns"), v: `${Math.max(t.buys24 + t.sells24, live?.trades.length ?? 0)}` },
      { l: tr("Age"), v: ago(t.created_at) },
    ];
  }, [t, usd, tr, live, liveVol]);

  if (!valid || t === null) {
    return (
      <main className="e-in e-page">
        <div className="e-panel e-empty" style={{ padding: "60px 20px" }}>
          <h2 style={{ margin: "0 0 8px", color: "var(--e-text)" }}>{tr("Token not found")}</h2>
          <p style={{ margin: "0 0 18px" }}>{tr(valid ? "We haven't seen this token on Elysium yet. New tokens show up within a minute." : "That doesn't look like a token address.")}</p>
          <Link href="/" className="e-btn pri">{tr("Back to Discover")}</Link>
        </div>
      </main>
    );
  }
  if (!t) {
    return (
      <main className="e-in e-page">
        <div className="e-skel" style={{ height: 70 }} />
        <div className="e-skel" style={{ height: 420 }} />
      </main>
    );
  }


  return (
    <main className="e-in e-page e-tokpage">
      <div className="e-tgrid">
        <div className="e-tmain">
          <button type="button" className="e-back" onClick={() => { if (history.length > 1) router.back(); else router.push("/"); }}>
            <span aria-hidden>←</span> {tr("Back")}
          </button>
          <section className="e-thead">
            <RingAvatar t={t} size={50} />
            <div className="e-tname">
              <h1>{t.name} <span>{t.symbol}</span></h1>
              <div className="e-tmeta">
                <span className="e-chipnet">Elysium</span>
                {t.ours && <span className="e-lock">{tr("LP locked")}</span>}
                <Copy text={t.address} />
              </div>
            </div>
            <div className="e-tprice">
              <b className="num">{money((t.mcap_hype ?? 0) * usd)}</b>
              <span className={`e-pill ${upDown(t.change24)}`}>{pct(t.change24)} {tr("24h")}</span>
            </div>
            <ShareButton t={t} links={links} mcap={money((t.mcap_hype ?? 0) * usd)} />
          </section>

          <section className="e-tstats">
            {stats.map((s) => <div key={s.l}><span>{s.l}</span><b className="num">{s.v}</b></div>)}
          </section>

          {/* phones have no side column: keep Shield up top, right by the Buy bar, never buried */}
          <div className="shield-m"><ShieldPanel token={t} shield={shield} dev={dev} /></div>

          <section className="e-panel"><EChart trades={trades} usd={usd} supply={supplyOf(t)} height={420} /></section>

          {/* phones: live trades full width; Buy / Sell sit in a bar at the bottom and open a sheet */}
          <section className="e-split">
            <div className="e-split-feed"><MiniTrades t={t} usd={usd} chain={live?.trades} /></div>
            <div className="e-panel e-split-box" id="trade"><TradeBox t={t} usd={usd} compact preset={buyPreset} /></div>
          </section>

          <ScoutPanel token={t} />

          <section className="e-panel">
            <div className="e-bar" style={{ flexDirection: "row" }}>
              <div className="e-tabs" role="tablist">
                {(["trades", "holders", "about"] as const).map((k) => <button key={k} type="button" role="tab" aria-selected={tab === k} className={`e-tab ${tab === k ? "on" : ""}`} onClick={() => setTab(k)}>{k === "trades" ? tr("Trades") : k === "holders" ? `${tr("Holders")} ${Math.max(t.holders || 0, live?.holders.length ?? 0) ? compact(Math.max(t.holders || 0, live?.holders.length ?? 0)) : ""}` : tr("About")}</button>)}
              </div>
            </div>
            {tab === "trades" && <Trades t={t} usd={usd} chain={live?.trades} />}
            {tab === "holders" && <Holders t={t} chain={live?.holders} />}
            {tab === "about" && <About t={t} links={links} />}
          </section>
        </div>

        <aside className="e-tside">
          <div className="e-panel" id="trade-side"><TradeBox t={t} usd={usd} preset={buyPreset} /></div>
          <ShieldPanel token={t} shield={shield} dev={dev} />
        </aside>
      </div>

      <div className="e-mbar">
        <button type="button" className="e-go buy" onClick={() => setSheet("buy")}>{tr("Buy")}</button>
        <button type="button" className="e-go sell" onClick={() => setSheet("sell")}>{tr("Sell")}</button>
      </div>
      {fresh && (
        <div className="e-sheet e-center" role="dialog" aria-modal="true" aria-label="Your coin is live" onClick={(e) => { if (e.target === e.currentTarget) setFresh(false); }}>
          <Burst />
          <Confetti />
          <Confetti />
          <div className="e-sheet-in e-live-card">
            <span className="e-live-ring"><TokenAvatar t={t} size={92} /></span>
            <span className="e-eyebrow"><i className="e-dot" />{tr("Live on Elysium")}</span>
            <h2>{t.name} <span className="dim">${t.symbol}</span></h2>
            <p className="muted">{tr("Your coin is trading now. Share it while it's fresh: the first hour decides most launches. You earn 30% of the fees on every trade.")}</p>
            <div className="e-ca">
              <span className="dim">CA</span>
              <code className="num">{t.address}</code>
              <Copy text={t.address} label={tr("Copy CA")} />
            </div>
            <ShareButton t={t} links={links} mcap={money((t.mcap_hype ?? 0) * usd)} fresh big />
            <div className="e-cta-btns" style={{ justifyContent: "center" }}>
              <Copy text={telegramText(t, links)} label={tr("Copy for Telegram")} />
              <button type="button" className="e-copy" onClick={() => { setFresh(false); history.replaceState(null, "", `/t/?a=${t.address}`); }}>{tr("Go to my coin")}</button>
            </div>
          </div>
        </div>
      )}
      {sheet && (
        <div className="e-sheet" role="dialog" aria-modal="true" aria-label={`${sheet === "buy" ? "Buy" : "Sell"} ${t.symbol}`} onClick={(e) => { if (e.target === e.currentTarget) setSheet(null); }}>
          <div className="e-sheet-in">
            <div className="e-sheet-h"><span className="e-grab" /><button type="button" className="e-btn e-icon" onClick={() => setSheet(null)} aria-label="Close">✕</button></div>
            <TradeBox t={t} usd={usd} side={sheet} preset={buyPreset} />
          </div>
        </div>
      )}
    </main>
  );
}
